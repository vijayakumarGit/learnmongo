﻿# consumer_html

> A Vue.js project

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader]
(http://vuejs.github.io/vue-loader).# phx-dce_consumer_DX



## TO USE FONT-AWESOME
``` bash
# URL to Vue project README.md contains full instructions
https://github.com/FortAwesome/vue-fontawesome#introduction

# Sample of adding a spinning icon and also using layers and layers-text
<div>  
    <fa-icon :icon="spinner" spin></fa-icon>
    <fa-layers full-width class="fa-4x">
    <fa-icon :icon="calendar"  size="2x" style="color:green;"/>
    <fa-layers-text style="font-weight:900; color:white;" value="28" transform="down-6, right-6" ></fa-layers-text>
    </fa-layers>
</div>

# In your .vue page import the icons you need and return them from data()
import { faSpinner } from '@fortawesome/pro-light-svg-icons'
import { faCalendar } from '@fortawesome/pro-solid-svg-icons'

export default {
  name: "App",
  data(){
    return{
      spinner: faSpinner,
      calendar: faCalendar
    }
  }
```