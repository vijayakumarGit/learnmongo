'use strict'
module.exports = {
  NODE_ENV: '"production"',
  DCE_API_URL: JSON.stringify('https://phx-dcep-api-master.ctnr.ctl.io/dce/'),
  UIM_API_URL: JSON.stringify('https://phx-uim-platform-master.ctnr.ctl.io/api/uim/'),
  CHAT_URL: '"https://chat.centurylink.digital"',
  DCE_NODE_API_URL: JSON.stringify('https://phx-node-dcep-api-master.ctnr.ctl.io/api/dcen/'),
  
}
