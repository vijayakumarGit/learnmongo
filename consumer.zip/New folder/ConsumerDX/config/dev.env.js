'use strict'
const merge = require('webpack-merge');
const prodEnv = require('./prod.env');

module.exports = merge(prodEnv, {
  NODE_ENV: '"development"',
  DCE_API_URL: JSON.stringify('https://dcep-api-master.kubeodc.corp.intranet/dce/'),
  //DCE_API_URL: JSON.stringify('http://phx-dcep-api-master.dcj.test.intranet/dce/'),
  UIM_API_URL: JSON.stringify('https://uim-platform-master.kubeodc.corp.intranet/api/uim/'),
  //UIM_API_URL: JSON.stringify('http://phx-uim-platform-master.dcj.test.intranet/api/uim/'),
  CHAT_URL: '"https://chat.centurylink.digital.dev"',
  DCE_NODE_API_URL: JSON.stringify('https://con-node-dcep-api-master.kubeodc.corp.intranet/api/dcen/'),
  //DCE_NODE_API_URL: JSON.stringify('http://phx-node-dcep-api-master.dcj.test.intranet/api/dcen/'),
  
  //this one is for the API calls to the backend services: offers, apointments, etc..
  //dev url
 //HSIAPI_URL : JSON.stringify('https://ne1itcdrhas36.dev.intranet:8443/hsiAPI/'),
 //HSIAPI_URL : JSON.stringify('http://ne1itcdrhas36.dev.intranet:8080/hsiAPI/'),
  //prod
  //HSIAPI_URL : JSON.stringify('http://hsiapi.corp.intranet:8080/hsiAPI/'),
  HSIAPI_URL : JSON.stringify('https://hsiapi.corp.intranet:8443/hsiAPI/'),
  //this one is for the initial address lookup
  ADDR_URL : JSON.stringify('https://geoamsrvcl.centurylink.com/geoam/addressmatch/'),

});
