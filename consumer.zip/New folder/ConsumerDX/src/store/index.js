import Vue from 'vue'
import Vuex from 'vuex'
import createPersistedState from 'vuex-persistedstate'

Vue.use(Vuex)

import { cart } from './modules/cart/index.js'
import { offers } from './modules/offers/index.js'
import { survey } from './modules/survey/index.js'
import { uiControl } from './modules/uiControl/index.js'

export default new Vuex.Store({
  modules: {
    cart,
    offers,
    survey,
    uiControl,
  },
  // state,
  // getters,
  // actions,
  // mutations,
  plugins: [ createPersistedState({ storage: window.sessionStorage }) ]
})