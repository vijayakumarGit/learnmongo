import { HTTP_DCE_NODE, HSIAPI } from '@/http-common';
import { RESPONSE_200, RESPONSE_201, RESPONSE_204 } from '@/mixin';

export const survey = {

    state: {
        surveyConfiguration: [{
            step: 1, title: 'Numbers of Users'
            , content: {
                path: {
                    next: 2
                }
                , chooseCard: {
                    label: 'How many people are<br>in your household?'
                    , labelSize: 'large'
                    , options: [
                        { label: '1-2', value: '1-2' }
                        , { label: '3-4', value: '3-4' }
                        , { label: '5-6', value: '5-6' }
                        , { label: '7+', value: '7+' }]
                    , optionsSize: ['9.5rem','6rem','auto']
                    , type: 'one'
                    , saveOn: 'members'
                }
                , mandatory: false
            }
        },{
            step: 2, title: 'Number of Devices'
            , content: {
                path: {
                    back: 1
                    , next: 3
                }
                , chooseCard: {
                    label: 'How many devices are used<br>in your home?'
                    , labelSize: 'large'
                    , options: [
                        { label: '1-5', value: '1-5' }
                        , { label: '6-10', value: '6-10' }
                        , { label: '11+', value: '11+' }]
                    , optionsSize: ['9.5rem','6rem','auto']
                    , type: 'one'
                    , saveOn: 'devices'
                }
                , mandatory: false
            }
        },{
            step: 3, title: 'Types of Services'
            , content: {
                path: {
                    back: 2
                    , next: 4
                }
                , chooseCard: {
                    label: 'How does your household use<br>the Internet?'
                    , labelSize: 'large'
                    , options: [
                        { label: `<div class="-d--flex -flex--column -align-items--center">
                            <svg height="72" width="72">
                                <circle cx="36" cy="36" r="24" stroke="#0047BB" stroke-width="1" fill="white" />
                                <text x="14" y="24" fill="#0047BB" transform="scale(2,2)">S</text>
                            </svg>
                            <p class="type-service__title">STANDARD USER</p>
                            <div class="-d--flex">
                                <svg height="24" width="22"><circle cx="11" cy="12" r="8" fill="#0047BB" /></svg>
                            </div>
                            <p style="min-height:9rem">Email<br>Web Surfing<br>Online Shopping<br>Social Media</p></div>` , value: 'Standard User' }
                        , { label: `<div class="-d--flex -flex--column -align-items--center">
                            <svg height="72" width="72">
                                <rect x="12" y="12" width="48" height="48" stroke="#0047BB" stroke-width="1" fill="white" />
                                <text x="14" y="24" fill="#0047BB" transform="scale(2,2)">P</text>
                            </svg>
                            <p class="type-service__title">POWER USER</p>
                            <div class="-d--flex -flex--row -align-items--center">
                                <svg height="24" width="22"><circle cx="10" cy="12" r="8" fill="#0047BB" /></svg>
                                <i class="fal fa-plus fa-xs" style="color:#808080"></i>
                                <svg height="24" width="22"><rect x="4" y="4" width="16" height="16" fill="#0047BB" /></svg>
                            </div>
                            <p style="min-height:9rem">Stream Video<br>Stream Music<br>VoIP Phone<br>Average Gaming<br>Work From Home</p></div>` , value: 'Power User' }
                        , { label: `<div class="-d--flex -flex--column -align-items--center">
                            <svg height="72" width="72">
                                <rect x="-24" y="27" width="48" height="48" stroke="#0047BB" stroke-width="1" fill="white" transform="rotate(-45)"></rect>
                                <text x="13" y="24" fill="#0047BB" transform="scale(2,2)">E</text>
                            </svg>
                            <p class="type-service__title">EXTREME USER</p>
                            <div class="-d--flex -flex--row -align-items--center">
                                <svg height="24" width="22"><circle cx="10" cy="12" r="8" fill="#0047BB" /></svg>
                                <i class="fal fa-plus fa-xs" style="color:#808080"></i>
                                <svg height="24" width="24"><rect x="4" y="4" width="16" height="16" fill="#0047BB" /></svg>
                                <i class="fal fa-plus fa-xs" style="color:#808080"></i>
                                <svg height="24" width="26"><rect x="-6" y="11" width="16" height="16" fill="#0047BB" transform="rotate(-45)" /></svg>
                            </div>
                            <p style="min-height:9rem">Home Office<br>Heavy Gaming<br>Constant Streaming<br>Upload Large Files<br>Multiple Power Users<br>24/7 Downloading</p></div>` , value: 'Extreme User' }]
                    , optionsSize: ['13.5rem','22rem','1rem']
                    , type: 'one'
                    , saveOn: 'services'
                }
                , mandatory: true
            }
        },{
            step: 4, title: 'Number of Activities'
            , content: {
                path: {
                    back: 3
                }
                , chooseCard: {
                    label: 'How many Internet activities<br>are happening at once?'
                    , labelSize: 'large'
                    , options: [
                        { label: '1-4' , value: '1-4' }
                        , { label: '5-8' , value: '5-8' }
                        , { label: '9-12' , value: '9-12' }
                        , { label: '13+' , value: '13+' }]
                    , optionsSize: ['9.5rem','6rem','auto']
                    , type: 'one'
                    , saveOn: 'activities'
                }
                , mandatory: true
            }
        }]
        , surveyResultsConfiguration: {
            recommendSpeed: {
                "1-4" : {
                    "Standard User" : "3"
                    , "Power User" : "18"
                    , "Extreme User" : "60"
                }
                , "5-8" : {
                    "Standard User" : "6"
                    , "Power User" : "36"
                    , "Extreme User" : "80"
                }
                , "9-12" : {
                    "Standard User" : "9"
                    , "Power User" : "54"
                    , "Extreme User" : "100"
                }
                , "13+" : {
                    "Standard User" : "11"
                    , "Power User" : "63"
                    , "Extreme User" : "1k"
                }
            }
            , serviceType: {
                "Standard User" : "Need to correct text for this standard type user"
                , "Power User" : "Between uploading and downloading to Dropbox, video chats on Skype and streaming videos on Netflix, you are using more bandwidth than the average household"
                , "Extreme User" : "Need to correct text for this extreme type user"
            }
        }
        , surveyId: ''
        , surveyUser: ''
        , surveyData: {}
        , currentSurvey: true
        , offerSelected: ''
    }
  
    , getters: {
        surveyConfiguration: function(state) {
            state.surveyConfiguration
            .sort((a, b) => a.step < b.step ? -1 : a.step > b.step ? 1 : 0);
    
            return state.surveyConfiguration;
        }
        , surveyResultsConfiguration: function(state) {
            return state.surveyResultsConfiguration;
        }
        , surveyId: function(state) {
            return state.surveyId;
        }
        , surveyUser: function(state) {
            return state.surveyUser;
        }
        , surveyData: function(state) {
            return state.surveyData;
        }
        , currentSurvey: function(state) {
            return state.currentSurvey;
        }
        , offerSelected: function(state) {
            return state.offerSelected;
        }
    }
  
    , mutations: {
        saveSurveyId: function(state, surveyId) {
            state.surveyId = surveyId;
        }
        , saveSurveyUser: function(state, surveyUser) {
            state.surveyUser = surveyUser;
        }
        , saveSurveyData: function(state, surveyData) {
            state.surveyData = surveyData;
        }
        , saveCurrentSurvey: function(state, currentSurvey) {
            state.currentSurvey = currentSurvey;
        }
        , saveOfferSelected: function(state, offerSelected) {
            state.offerSelected = offerSelected;
        }
        , resetSurveyId: function(state) {
            state.surveyId = '';
        }
        , resetSurveyUser: function(state) {
            state.surveyUser = '';
        }
        , resetSurveyData: function(state) {
            state.surveyData = {};
            state.surveyConfiguration.forEach(configuration => {
                for (let item in configuration.content) {
                    if (!!configuration.content[item].saveOn) {
                        state.surveyData[configuration.content[item].saveOn] = '';
                    }
                }
            });
        }
        , resetCurrentSurvey: function(state) {
            state.currentSurvey = true;
        }
        , resetOfferSelected: function(state) {
            state.offerSelected = {}
        }
    }
    , actions: {
        getSurveyDataById: function(context) {
            //TODO. REVIEW THIS CODE
            return HTTP_DCE_NODE.get('accounts/' + context.getters.surveyUser + '/surveys/' + context.getters.surveyId)
                .then(response => {
                    if (response.status === RESPONSE_200 && !!response.data.length > 0 && response.data[0].result) {
                        context.commit('saveSurveyData', response.data[0].result.survey);
                        context.commit('saveCurrentSurvey', response.data[0].current);
                        context.commit('saveOfferSelected', response.data[0].result.offer);
                    }
                })
                .catch(error => console.log('surveyStore~getSurveyDataById error = ' + error));
        }
        , getCurrentSurveyData: function(context) {
            //TODO. REVIEW THIS CODE
            return HTTP_DCE_NODE.get('accounts/' + context.getters.surveyUser + '/getCurrentSurvey')
                .then(response => {
                    if (response.status === RESPONSE_200 && !!response.data.length > 0 && response.data[0].result) {
                        context.commit('saveSurveyId', response.data[0].surveyId);
                        context.commit('saveSurveyData', response.data[0].result.survey);
                        context.commit('saveCurrentSurvey', response.data[0].current);
                        context.commit('saveOfferSelected', response.data[0].result.offer);
                    }
                })
                .catch(error => console.log('surveyStore~getCurrentSurveyData error = ' + error));
        }
        , saveSurveyData: function(context) {
            let headers = { 'Content-Type' : 'application/json' };
            let body = {
                'acctId' : context.getters.surveyUser
                , 'current' : context.getters.currentSurvey
                , 'result' : {
                    'survey' : context.getters.surveyData
                    , 'offer' : context.getters.offerSelected
                }
            };

            if (!!context.getters.surveyId) {
                body['surveyId'] = context.getters.surveyId;
            }

            //TODO. REVIEW THIS CODE
            return HTTP_DCE_NODE.post('accounts/' + context.getters.surveyUser + '/surveys', JSON.stringify(body), { headers: headers })
            .then(response => {
                if (response.status === RESPONSE_201 && !!response.data.length > 0 && response.data[0].surveyId) {
                    context.commit('saveSurveyId', response.data[0].surveyId);
                    context.commit('saveSurveyData', response.data[0].result.survey);
                    context.commit('saveCurrentSurvey', response.data[0].current);
                    context.commit('saveOfferSelected', response.data[0].result.offer);
                }
            })
            .catch(error => console.log('surveyStore~saveSurveyData error = ' + error));
        }
        , deleteSurveyData: function(context) {
            //TODO. REVIEW THIS CODE
            return HTTP_DCE_NODE.delete('accounts/' + context.getters.surveyUser + '/surveys/' + context.getters.surveyId)
                .then(response => {
                    if (response.status === RESPONSE_204) {
                        context.commit('resetSurveyId');
                        context.commit('resetSurveyData');
                        context.commit('resetCurrentSurvey');
                        context.commit('resetOfferSelected');
                    }
                })
                .catch(error => console.log('surveyStore~deleteSurveyData error = ' + error));
        }
        , shareSurvey: function(context, payload) {
            let surveyURL = `${payload.baseURL}/Survey?surveyNum=${context.getters.surveyId}`;
            let services = context.getters.surveyData.services[0];
            let activities = context.getters.surveyData.activities[0];

            let headers = { 'Content-Type' : 'application/json' };
            let body = {
                'from': 'cristina.torres@centurylink.com'
                , 'to': payload.emailTo
                , 'subject': 'CenturyLink Survey Result'
                , 'content': '<p>Hi Peter,</p><p>It was great talking to you. Please find your tailored package recommendation and personally selected options below and let me know if you have any further questions. I am here to help.</p><p>Best,<br>Frank</p>'
                , 'userType': services
                , 'userTypeDescription': context.getters.surveyResultsConfiguration.serviceType[services]
                , 'recommendedSpeed': context.getters.surveyResultsConfiguration.recommendSpeed[activities][services]
                , 'recommendedSpeedUnit': 'Mbps'
                , 'quizButtonUrl': surveyURL
                , 'checkoutButtonUrl': surveyURL
                , 'templateName': 'survey-result-email-template.ftl'
                , 'address': context.getters.surveyData.address.fullAddress
                , 'surveyResultOfferList': payload.offersList
            };

            return HSIAPI.post('sendSurveyResultMail', JSON.stringify(body), { headers: headers })
        }
    }
  }