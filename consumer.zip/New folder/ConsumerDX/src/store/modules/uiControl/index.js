//this is for controling the apearance of ui elements, components, ..
export const uiControl = {
    state: {
      mobileView:false,
      addressText: '',
      addressId: ''
    },
  
    getters: {
        isMobileView: function(state){
            return state.mobileView
        },
        getAddress: function(state){
            return state.addressText
        },
        getAddressId: function(state){
            return state.addressId;
        }
    },

    //Code will be replaced with BOT API
    mutations: {
        setMobileView: function(state, payload){
            state.mobileView = payload;
        },
        setAddressText: function(state, payload){
            state.addressText = payload;
        },
        setAddressId: function(state,payload){
            state.addressId = payload;
        }
    },

    actions: {
        setMobileView: function(context,payload){
            context.commit('setMobileView')
        },
        setAddressText: function(context, payload){
            context.commit('setAddressText', payload)
        },
        setAddressId: async function(context, payload){
            context.commit('setAddressId',payload);
            await context.dispatch("setOffersStore", payload);
        }
    }
}