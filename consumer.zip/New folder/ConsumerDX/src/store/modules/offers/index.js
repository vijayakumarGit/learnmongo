//************************************* */
//Mike Diehl - Store to hold the Offers for Addresses
//7-9-2018
//The offers object will not get stored in Mongo
//It will get populated when an exsiting user signs in and when a new user adds addresses
//************************************ */

import { HSIAPI } from "@/http-common";
// import axios from 'axios'

export const offers = {
    state: {
        offersPerAddress: []
        , selectedOffer: []
        , taxApiObj: []
        , appointmentApiObj: []
        , submitPaymentApiObj: []
        , submitOrderApiObj: []
        , speedDescription: {
            '1000 Mbps'  : [ 'Multiple users and a highly-connected home', 'Stream multiple HD or 4K movies', 'Download/upload at amazing speeds' ]
            , '140 Mbps' : [ 'Multiple users and a highly-connected home', 'Stream multiple HD or 4K movies', 'Download/upload at amazing speeds' ]
            , '120 Mbps' : [ 'Multiple users and a highly-connected home', 'Stream multiple HD movies', 'Download/upload at amazing speeds' ]
            , '100 Mbps' : [ 'Connect multiple users and devices', 'Stream multiple HD movies', 'Download/upload at amazing speeds' ]
            , '80 Mbps'  : [ 'Support multiple users and devices', 'Stream multiple HD movies', 'Online gaming at blazing speeds' ]
            , '60 Mbps'  : [ 'Multi player gaming', 'Streaming videos', 'Supporting multiple devices' ]
            , '40 Mbps'  : [ 'Seamless speed on multiple devices', 'Downloading multiple HD movies', 'Streaming videos' ]
            , '20 Mbps'  : [ 'Downloading HD movies', 'Streaming videos', 'Playing games at fast speeds' ]
            , '12 Mbps'  : [ 'Watching videos', 'Downloading music', 'Multiplayer gaming' ]
            , '10 Mbps'  : [ 'Watching videos', 'Downloading music', 'Multiplayer gaming' ]
            , '7 Mbps'   : [ 'Online shopping', 'Social networking', 'Downloading music' ]
            , '5 Mbps'   : [ 'Online shopping', 'Social networking', 'Downloading music' ]
            , '3 Mbps'   : [ 'Online shopping', 'Social networking', 'Downloading music' ]
            , '1.5 Mbps' : [ 'Email', 'Surfing the internet', 'Social Networking' ]
        }
        , pricesByTier: {
            1 : { regular: 45, haveDiscount: false }
            , 2 : { regular: 55, haveDiscount: true, discount: 45, startOn: new Date("2018-12-31"), endOn: new Date("2019-03-31") }
            , 3 : { regular: 65, haveDiscount: true, discount: 55, startOn: new Date("2018-12-31"), endOn: new Date("2019-03-31") }
            , 4 : { regular: 85, haveDiscount: true, discount: 65, startOn: new Date("2018-12-31"), endOn: new Date("2019-03-31") }
        }
        , installContent: {
            '1000 Mbps' : { 'GPON' : [ 'Tech Installation Required (FREE)', 'State-of-the-art technology delivers this speed to your home. Proper installation requires one of our technicians to install the service.' ] }
            , '140 Mbps' : { 'PB' : [ 'Tech Installation Required (FREE)', 'State-of-the-art technology delivers this speed to your home. Proper installation requires one of our technicians to install the service.' ] }
            , '120 Mbps' : { 'PB' : [ 'Tech Installation Required (FREE)', 'State-of-the-art technology delivers this speed to your home. Proper installation requires one of our technicians to install the service.' ] }
            , '100 Mbps' : {
                'GPON' : [ 'Tech Installation Required (FREE)', 'State-of-the-art technology delivers this speed to your home. Proper installation requires one of our technicians to install the service.' ]
                , 'PB' : [ 'Tech Installation Required (FREE)', 'State-of-the-art technology delivers this speed to your home. Proper installation requires one of our technicians to install the service.' ]
            }
            , '80 Mbps' : { 'PB' : ['Tech Installation Required ($99)', 'State-of-the-art technology delivers this speed to your home. Proper installation requires one of our technicians to install the service.'] }
            , '60 Mbps' : { 'PB' : ['Tech Installation Required ($99)', 'State-of-the-art technology delivers this speed to your home. Proper installation requires one of our technicians to install the service.'] }
            , '40 Mbps' : {
                'GPON' : ['Tech Installation Required ($99)', 'State-of-the-art technology delivers this speed to your home. Proper installation requires one of our technicians to install the service.']
                , 'PB' : ['Tech Installation Required ($99)', 'State-of-the-art technology delivers this speed to your home. Proper installation requires one of our technicians to install the service.']
            }
            , '20 Mbps'  : { 'PB' : ['Tech Installation Required ($99)', 'State-of-the-art technology delivers this speed to your home. Proper installation requires one of our technicians to install the service.'] }
            , '12 Mbps'  : { 'PB' : ['Tech Installation Required ($99)', 'State-of-the-art technology delivers this speed to your home. Proper installation requires one of our technicians to install the service.'] }
            , '10 Mbps'  : { 'PB' : ['Tech Installation Required ($99)', 'State-of-the-art technology delivers this speed to your home. Proper installation requires one of our technicians to install the service.'] }
            , '7 Mbps'   : { 'PB' : ['Tech Installation Required ($99)', 'State-of-the-art technology delivers this speed to your home. Proper installation requires one of our technicians to install the service.'] }
            , '5 Mbps'   : { 'PB' : ['Tech Installation Required ($99)', 'State-of-the-art technology delivers this speed to your home. Proper installation requires one of our technicians to install the service.'] }
            , '3 Mbps'   : { 'PB' : ['Tech Installation Required ($99)', 'State-of-the-art technology delivers this speed to your home. Proper installation requires one of our technicians to install the service.'] }
            , '1.5 Mbps' : { 'PB' : ['Tech Installation Required ($99)', 'State-of-the-art technology delivers this speed to your home. Proper installation requires one of our technicians to install the service.'] }
            , 'other' : [ 'Tech and Self Install Available', 'The speed allows you to install service yourself if you are comfortable doing so. Technician installation is also available.' ]
        }
        , onlineOffers: {
            '1000 Mbps' : { startOn: new Date(1900, 0, 1), endOn: new Date("2019-03-01") }
            , '140 Mbps': { startOn: new Date(1900, 0, 1), endOn: new Date("2019-03-01") }
            , '120 Mbps': { startOn: new Date(1900, 0, 1), endOn: new Date("2019-03-01") }
            , '100 Mbps': { startOn: new Date("2018-12-31"), endOn: new Date("2019-03-01") }
        }
    },
  
    getters: {
        getOffers: function (state) {
            return state.offersPerAddress;
        },
        getSelectedOffer: function (state) {
            return state.selectedOffer;
        },
        getTaxApiObj: function (state) {
            return state.taxApiObj;
        },
        getAppointmentApiObj: function (state) {
            return state.appointmentApiObj;
        },
        getSubmitPaymentApiObj: function (state) {
            return state.submitPaymentApiObj;
        },
        getSubmitOrderApiObj: function (state) {
            return state.submitOrderApiObj;
        }
        , getSpeedDescription: function(state) {
            return state.speedDescription;
        }
        , getPricesByTier: function(state) {
            return state.pricesByTier;
        }
        , getInstallContent: function(state) {
            return state.installContent;
        }
        , getOnlineOffers: function(state) {
            return state.onlineOffers;
        }
    },
  
    mutations: {
        setOffersStore: function (state, offerObj) {
            state.offersPerAddress.push(offerObj);
        },
        resetOffers: function (state) {
          state.offersPerAddress = [];
          state.selectedOffer = [];
          state.taxApiObj = [];
          state.appointmentApiObj = [];
          state.submitPaymentApiObj = [];
          state.submitOrderApiObj = [];
        }, 
        setSelectedOffer: function(state, offer){
            state.selectedOffer = offer;
        },
        setTaxApiObj: function(state, obj){
            state.taxApiObj = obj;
        },
        setAppointmentApiObj: function(state, obj){
            state.appointmentApiObj = obj;
        },
        setSubmitPaymentApiObj: function(state, obj){
            state.submitPaymentApiObj = obj;
        },
        setSubmitOrderApiObj: function(state, obj){
            state.submitOrderApiObj = obj;
        }
    },

    actions: {
        setOffersStore: async function (context, addressId){
            //clear the store
            context.commit('resetOffers');
            await getOfferData(context, addressId, storeOffers);
        },
        resetOffersData: function(context){
            context.commit('resetOffers');
        },
        setSelectedOffer: function(context, offer){
            context.commit('setSelectedOffer', offer);
        },
        setTaxApiObj: function(context, obj){
            context.commit('setTaxApiObj', obj);
        },
        setAppointmentApiObj: function(context, obj){
            context.commit('setAppointmentApiObj', obj);
        },
        setSubmitPaymentApiObj: function(context, obj){
            context.commit('setSubmitPaymentApiObj', obj);
        },
        setSubmitOrderApiObj: function(context, obj){
            context.commit('setSubmitOrderApiObj', obj);
        }
    },  
    
}

function getOfferData(context, addressId, callback){
    // var geoAddressId = address.completeAddress.geoAddressId;
    var body = {"orderRefNum" : "orderRefTest333", "addressId" : addressId };

    return HSIAPI.post("offers", body, { headers: {
            'Access-Control-Allow-Origin' : '*', 
            'Access-Control-Allow-Headers' : 'Origin, Content-Type, Authorization, X-Auth-Token',
            'Access-Control-Allow-Methods' : 'GET,PUT,POST,DELETE,PATCH,OPTIONS'
        } } )
        .then(response => {
            callback(context, response, addressId);
        })
        .catch( function(error) {
            console.log('offerStore~offers error = ' + error);
        });
}

function storeOffers(context, response, addressId){
    var offerObj = {};
    var offersArr = [];
    offersArr = response.data;
    offerObj.geoAddressId = addressId;
    offerObj.offers = offersArr.offersList;
    context.commit('setOffersStore', offerObj);
}
