
import { HTTP_DCE_NODE } from "@/http-common";

export const cart = {
    state: {
        order: {
            orderRefNumber: '',
            cartRefNumber:'',
            geoAddressId: '', 
            baidAccountId: '',
            orderNumber: '',
            orderStatus: '',    //inprocess, complete, acknowledged       
            oneTimeCost: 0,
            monthlyCost: 0,
            oneTimeTax: 0,
            monthlyTax: 0,
            internet: {
                package: '',
                packageDescription: '',
                price: 0,
                modem: '', //   lease/purchase  
                modemCost: 0,
                status: '',
                skuNames: '',
                modemSkuName: '',
                modemInstallSkuNames: '',
            },
            homePhone: {
                package: '',
                price: 0,
                useExistingNumber: false, //    bool    
                phoneNumber: '',
                status: '',
            },
            installation: {
                installType: '',
                installCost: 0,
                installAppt: {
                    date: '',
                    slot: ''
                },
            },
            accountInfo: {
                email: '',
                firstName: '',
                lastName: '',
                phoneNumber: '',
                dateOfBirth: '',
                paperless: true, //    bool    
                promotionalMaterial: true, //  bool    
                billDifferentAddress: false, // bool    
                sameShipAddress: true, //  bool    
            },
            sendBilltoDiffAddress: {
                firstName: '',
                lastName: '',
                streetAddr: '',
                apt: '',
                city: '',
                state: '',
                zip: '',
            },
            shiptoDiffAddress: {
                firstName: '',
                lastName: '',
                streetAddr: '',
                apt: '',
                city: '',
                state: '',
                zip: '',
            },
            creditCardInfo: {
                number: '',
                holderName: '',
                expMY: '',
                cvv: '',
                billingAddress: {
                    sameAsService: false, //    bool
                    firstName: '',
                    lastName: '',
                    streetAddr: '',
                    apt: '',
                    city: '',
                    state: '',
                    zip: '',
                }
            }
        },
    },

    getters: {
        order: function (state) {
            return state.order
        },
        oneTimeCost: function (state) {
            return state.order.oneTimeCost;
        },
        monthlyCost: function (state) {
            return state.order.monthlyCost;
        }
    },

    mutations: {
        updateOrder: function (state, payload) {
            state.order = payload;
            
            //update totals            
            if(state.order.internet.modem === 'Purchase') {
                state.order.oneTimeCost = Number(
                    Number(state.order.internet.modemCost) +
                    Number(state.order.installation.installCost) +                
                    Number(state.order.oneTimeTax)
                );
                state.order.monthlyCost = Number(
                    Number(state.order.internet.price) +
                    Number(state.order.homePhone.price) +
                    Number(state.order.monthlyTax)
                );
            } else {
                state.order.oneTimeCost = Number(                    
                    Number(state.order.installation.installCost) +                
                    Number(state.order.oneTimeTax)
                );
                state.order.monthlyCost = Number(
                    Number(state.order.internet.modemCost) +
                    Number(state.order.internet.price) +
                    Number(state.order.homePhone.price) +
                    Number(state.order.monthlyTax)
                );
            }
            //save to the API
            //orders 
            if (sessionStorage.getItem("accountId")){
                state.order.acctId = sessionStorage.getItem("accountId");
                HTTP_DCE_NODE.post("orders", JSON.stringify(state.order), { 
                    headers: { 
                        'Access-Control-Allow-Origin' : '*', 
                        'Content-Type': 'application/json' 
                    } })
                .then(response => {
                    // var statusCode = response.status;
                    // console.log("Post.then : " + JSON.stringify(statusCode));
                })
                .catch(function(error) {
                    console.error("Post.catch~update order error: " + error);
                });
            }
        },
        getOrders: function (state, accountId) {
            //here we need to make a call to the API to get current order
            var headers = {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            };
          HTTP_DCE_NODE.get("orders/"+accountId, headers)
            .catch(function(error) {
                console.error("orderStore/getOrders~error: " + JSON.stringify(error));
                //state.order = [];
            })
            .then(response => {
                this.responseData = response.data;
                var order = this.responseData;
                //console.log('orderStore/getOrder~res = '+ JSON.stringify(order));
                state.order = order;
            });
          
        },
        resetOrders: function(state){ 
            let baseOrderDetail = {
                orderRefNumber: state.order.orderRefNumber,
                cartRefNumber: '',
                geoAddressId: '', 
                baidAccountId: '',
                orderNumber: '',
                orderStatus: '',    //inprocess, complete, acknowledged       
                oneTimeCost: 0,
                monthlyCost: 0,
                oneTimeTax: 0,
                monthlyTax: 0,
                internet: {
                    package: '',
                    packageDescription: '',
                    price: 0,
                    modem: '', //   lease/purchase  
                    modemCost: 0,
                    status: '',
                    skuNames: '',
                    modemSkuName: '',
                    modemInstallSkuNames: '',
                },
                homePhone: {
                    package: '',
                    price: 0,
                    useExistingNumber: false, //    bool    
                    phoneNumber: '',
                    status: '', 
                },
                installation: {
                    installType: '',
                    installCost: 0,
                    installAppt: {
                        date: '',
                        slot: ''
                    },
                },
                accountInfo: {
                    email: '',
                    firstName: '',
                    lastName: '',
                    phoneNumber: '',
                    dateOfBirth: '',
                    paperless: true, //    bool    
                    promotionalMaterial: true, //  bool    
                    billDifferentAddress: false, // bool    
                    sameShipAddress: true, //  bool    
                },
                sendBilltoDiffAddress: {
                    firstName: '',
                    lastName: '',
                    streetAddr: '',
                    apt: '',
                    city: '',
                    state: '',
                    zip: '',
                },
                shiptoDiffAddress: {
                    firstName: '',
                    lastName: '',
                    streetAddr: '',
                    apt: '',
                    city: '',
                    state: '',
                    zip: '',
                },
                creditCardInfo: {
                    number: '',
                    holderName: '',
                    expMY: '',
                    cvv: '',
                    billingAddress: {
                        sameAsService: false, //    bool
                        firstName: '',
                        lastName: '',
                        streetAddr: '',
                        apt: '',
                        city: '',
                        state: '',
                        zip: '',
                    }
                }
            }
            state.order = Object.assign({}, baseOrderDetail); 
        }
    },

    actions: {
        updateOrderAll: function (context, dataobj) {
            // this should update the whole record..get the whole record in your component, update the fields you want and pass it back
            var obj = JSON.parse(dataobj);
            context.commit('updateOrder', obj);
        },
        getOrders: function (context, accountId){
            context.commit('getOrders', accountId)
        },
        resetOrders: function (context) {
            context.commit('resetOrders');
        }
    },

    
}