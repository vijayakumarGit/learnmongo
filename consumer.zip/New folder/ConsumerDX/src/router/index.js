import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/components/Home'
import ChooseSpeed from '@/components/orderFlow/ChooseSpeed'
import ServiceOptions from '@/components/orderFlow/ServiceOptions'
import YourInformation from '@/components/orderFlow/YourInformation'
import Survey from '@/components/survey/Survey'
import { SURVEY_RESULTS } from '@/mixin';
import Store from '@/store';

Vue.use(Router)

const router = new Router({
	mode: 'history',
	routes: [
		{
			path: '/',
			name: 'Home',
			component: Home,
			secure: false
		},
		{
			path: '/ChooseSpeed',
			name: 'ChooseSpeed',
			component: ChooseSpeed,
			secure: false
		},
		{
			path: '/ServiceOptions',
			name: 'ServiceOptions',
			component: ServiceOptions,
			secure: false
		},
		{
			path: '/YourInformation',
			name: 'YourInformation',
			component: YourInformation,
			secure: false
		},
		{
			path: '/Survey',
			name: 'Survey',
			component: Survey,
			secure: true
		}
	]
})

router.beforeEach((to, from, next) => {
	//Look at all routes from above
	router.options.routes.forEach((route) => {
		//If this is the current route and it's secure
		if (to.matched[0].path === route.path) {
			// let surveyQuery = false;

			if ( route.path === "/Survey" && !!to.query && !!to.query['surveyNum'] ) {
				sessionStorage.setItem(
					'survey-goto'
					, JSON.stringify({ goto : SURVEY_RESULTS, currentStep : 0, surveyId : to.query.surveyNum }));
				// surveyQuery = true;
				return next('/Survey');
			}
			else if ( route.path === "/ChooseSpeed" && !!to.query && !!to.query['sla'] ){
				var addressText = to.query.sla;
				var addressId = to.query.aid;
				Store.dispatch("setAddressText", addressText);
				Store.dispatch("setAddressId", addressId);
				return next("/ChooseSpeed");
			}			
		} else {
 	 		//proceed as normal
	 		next();
		}
	});
});

export default router;
