//constants
export const SMART_LIFE = 'Smartlife';
export const CONFIRM_ORDER = 'ConfirmOrder';

export const SL_OVERVIEW = 'Overview';
export const SL_DEVICES = 'Devices';
export const SL_PROFILES = 'Profiles';
export const SL_PARENTALCTRL = 'Parental Control';
export const SL_SCENES = 'Scenes';
export const SL_INSIGHTS = 'Insights';
export const SL_SUPPORT = 'Support';

export const ACCT_MANAGEMENT = 'Account Management';
export const ACCT_ACCOUNT = 'Account';
export const ACCT_PAYMENT = 'Payment';
export const ACCT_LINKEDACCOUNTS = 'Linked Accounts';
export const ACCT_REFERRALS = 'Referrals';
export const ACCT_ACTIVITY = 'Activity';
export const ACCT_SUPPORT = 'Support';

export const USER = 'user';

export const PLAY = 'play';
export const PAUSE = 'pause';

export const CATEGORY_ABC = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';


//network
export const NETWORK = 'Network';

export const NB_OVERVIEW = 'Overview';
export const NB_DEVICES = 'Connect Device';
export const NB_SETTING = 'Settings';
export const NB_INSIGHTS = 'Insights';
export const NB_SUPPORT = 'Support';
export const NB_NETWORK_2 = 'Network2';
export const GH_SEARCH = 'Self-Help-Search';
export const GH_RESULTS = 'Self-Help-Results';
export const GH_SUPPORT = 'Additional-Support';
export const GH_CALL = 'Get-Help-Call';
export const GH_WAIT = 'Get-Help-Wait-Time';
export const GH_CALLSCREEN = '';

export const IO_MAIN = 'OrderChooseServices';
export const IO_EQUIPMENT = 'EquipmentCard';

//pending services change
export const PS_CURRENT_SERVICES = 'Current Services';
export const PS_PENDING_SERVICES = 'Pending Services';

export const VO_SELECTPHONENUMBER = 'ShopCommunicatorDigitalHomePhone';
export const STATUS_ORDER_FLOW = 'Order-Status-Tracker';
export const CONFRIM_ORDER_FLOW = [
      {pageName:'Installation', pageTitle: 'Installation'}
    , {pageName:'Appointment', pageTitle: 'Appointment'}
    , {pageName:'AccountInformationCard', pageTitle: 'Account Information'}
    , {pageName: 'BillDiffAddress', pageTitle: 'Bill Different Address'}
    , {pageName: 'PaymentInformation', pageTitle: 'Payment Information'}
    , {pageName: 'PurchaseComplete', pageTitle: 'Thank you!<br>We have received your order'}  
    , {pageName: 'NextStepTracker', pageTitle: 'What Can be Expected'}
    , {pageName: 'WhatToExpectBill', pageTitle: 'What to Expect from your Bill'}
    , {pageName: 'InternetOrderTracker', pageTitle: 'Order Status'}
    , {pageName: 'InstallDateChangeConfirm', pageTitle: 'Order Status'}
    , {pageName: 'MergeInstallDate', pageTitle: 'Order Status'}
    , {pageName: 'Error', pageTitle: 'Ops.....Something has gone wrong. Please try again or contact customer service.'}

    // , {pageName: ''}
];

export const INTERNET_MODAL = 'Internet';
export const INTERNET_OVERVIEW = 'Overview';
export const INTERNET_INSIGHTS = 'Insights';
export const INTERNET_SUPPORT = 'Support';

export const SURVEY = 'Survey';
export const SURVEY_RESULTS = 'SurveyResults';
export const SURVEY_SHARE = 'SurveyShare';

export const RESPONSE_200 = 200;
export const RESPONSE_201 = 201;
export const RESPONSE_204 = 204;

export const VALIDATION = {
    methods:{
      validateCCNumber: function (cardnum) {
        var ccNum = /\b\d{4}(| |-)\d{4}\1\d{4}\1\d{4}\b/;
        return ccNum.test(cardnum);
      },
      validateCCExp: function (mmyy) {
        //alert("valid exp date? " + mmyy);
        var ccexpr = /\b(0[1-9]|1[0-2])\/([0-9]{2})\b/;
        //alert("valid exp date again? " + mmyy)
        return ccexpr.test(mmyy);
      },
      validateCVV: function (cvv) {
        var cv = /\b\d{3}\b/;
        return cv.test(cvv);
      },
      validateZip: function (zip) {
        var zp = /^\d{5}(?:[-\s]\d{4})?$/;
        return zp.test(zip);
      }
    }
  }

//AddressCheck flow
export const ADDRESS_CHECK = 'AddressCheck';

//Connect flow
export const CONNECT = 'Connect';

export const C_CONVERSATIONS = 'Conversations';
export const C_CONTACTS = 'Contacts';
export const C_SETTINGS = 'Settings';
export const C_INSIGHTS = 'Insights';
export const C_SUPPORT = 'Support';
export const C_ADDHMPHONE = 'Add Home Phone';
export const C_CHANGEHMPHONE = 'Change Home Phone';

export const C_OBJ_CONVERSATIONS = '{ "selectedModal": "communicator", "baseObj": { "baseType":"connect-conversations", "baseSubType":"", "baseValidated": false, "baseUpdatedByTopMenu": true }, "acctObj": { "servicePhoneNumber":"" } }';
export const C_OBJ_CONTACTS = '{ "selectedModal": "communicator", "baseObj": { "baseType":"connect-contacts", "baseSubType":"", "baseValidated": false, "baseUpdatedByTopMenu": true }, "acctObj": { "servicePhoneNumber":"" } }';
export const C_OBJ_SETTINGS = '{ "selectedModal": "communicator", "baseObj": { "baseType":"connect-settings", "baseSubType":"", "baseValidated": false, "baseUpdatedByTopMenu": true }, "acctObj": { "servicePhoneNumber":"" } }';
export const C_OBJ_INSIGHTS = '{ "selectedModal": "communicator", "baseObj": { "baseType":"connect-insights", "baseSubType":"", "baseValidated": false, "baseUpdatedByTopMenu": true }, "acctObj": { "servicePhoneNumber":"" } }';
export const C_OBJ_SUPPORT = '{ "selectedModal": "communicator", "baseObj": { "baseType":"connect-support", "baseSubType":"", "baseValidated": false, "baseUpdatedByTopMenu": true }, "acctObj": { "servicePhoneNumber":"" } }';
export const C_OBJ_ADDHOMEPHONE = '{ "selectedModal": "communicator", "baseObj": { "baseType":"connect-addhomephone", "baseSubType":"", "baseValidated": false, "baseUpdatedByTopMenu": true }, "acctObj": { "servicePhoneNumber":"" } }';
export const C_OBJ_CHANGEHOMEPHONE = '{ "selectedModal": "communicator", "baseObj": { "baseType":"connect-changehomephone", "baseSubType":"", "baseValidated": false, "baseUpdatedByTopMenu": true }, "acctObj": { "servicePhoneNumber":"" } }';
export const C_OBJ_ERROR = '{ "selectedModal": "communicator", "baseObj": { "baseType":"connect-error", "baseSubType":"", "baseValidated": false, "baseUpdatedByTopMenu": true }, "acctObj": { "servicePhoneNumber":"" } }';

export const CONV_DEFAULT = "converse";
export const CONV_MATURE = "matureaccount";
export const CONV_START = "startconv";

export const C_OBJ_SRCH_CONTACT = '{ "name": { "display": "" }, "phones": [ { "number": "" } ], "emails": [ { "address": "" } ], "photo": "" }';
export const C_OBJ_NEW_CONTACT = '{ "acctId": "", "name": { "first": "", "last": "", "mi": "", "display": "", "prefix": "", "suffix": "" }, "phones": [ { "_id": "", "type": "", "code": "", "number": "", "ext": "", "preferred": true } ], "emails": [ { "_id": "", "type": "", "address": "", "preferred": true } ], "addresses": [ { "_id": "", "type": "", "fullAddress": "", "description": "", "street": "", "street_2": "", "city_name": "", "state_abbreviation": "", "state": "", "zipCode": "", "country": "" } ], "status": "connect", "photo": "", "addressbook": "connect" }';
export const C_OBJ_DFLT_CONTACT = '{ "acctId": "", "name": { "first": "John", "last": "Doe", "mi": "", "display": "John Doe", "prefix": "", "suffix": "" }, "phones": [ { "type": "work", "code": "+1", "number": "000-000-0000", "preferred": false } ], "emails": [ { "type": "work", "address": "john.doe@identity.unknown.org", "preferred": false } ], "addresses": [ { "_id": "", "type": "", "fullAddress": "", "description": "", "street": "", "street_2": "", "city_name": "", "state_abbreviation": "", "state": "", "zipCode": "", "country": "" } ], "status": "online", "image": "", "addressBook": "connect" }';


