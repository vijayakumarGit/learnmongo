import axios from 'axios'

export const HTTP = axios.create({
    baseURL: process.env.DCE_API_URL
})

export const HTTPLOGIN = axios.create({
    baseURL: process.env.UIM_API_URL
})

export const HTTP_DCE_NODE = axios.create({
    baseURL: process.env.DCE_NODE_API_URL
})

export const HSIAPI = axios.create({
    baseURL: process.env.HSIAPI_URL
})

export const ADDRURL = axios.create({
    baseURL: process.env.ADDR_URL
})
