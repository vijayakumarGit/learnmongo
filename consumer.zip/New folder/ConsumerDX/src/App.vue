<template>
  <div id="mainContainer">
    <NavBar class="siteWidth"></NavBar>
    <div id="mainContent">  
      <router-view class="siteWidth"></router-view>
    </div>
    <div id="mainFooter" v-show="showFooter">
      <Footer class="siteWidth"></Footer>
    </div>
  </div>
</template>

<script>
import Home from "./components/Home"
import NavBar from "@/components/NavBar"
import Footer from "@/components/Footer"

export default {
  name: "App",
  components: {
    Home,
    NavBar, 
    Footer
  }
  ,data(){
    return{
      showFooter: true
    }
  }
  ,computed: {
		weAreSignedIn(){
      return this.$store.getters.loggedIn;
    }
  }
  ,watch:{
    weAreSignedIn: function(newVal) {
       this.showFooter = !newVal;
    }
  }  
  ,mounted: function() {
    let hcdeTknUnpkg = document.createElement('script');    
		hcdeTknUnpkg.setAttribute('src',"https://unpkg.com/hyperhtml@2.13.0/min.js");
		hcdeTknUnpkg.async = true;
		document.head.appendChild(hcdeTknUnpkg);

		let hcdeTknEncrypt = document.createElement('script');    
		hcdeTknEncrypt.setAttribute('src',"/static/jsencrypt.js");
		hcdeTknEncrypt.async = true;
		document.head.appendChild(hcdeTknEncrypt);

		let hcdeTknService = document.createElement('script');    
		hcdeTknService.setAttribute('src',"/static/hcdeTokenServiceApi.js");
		hcdeTknService.async = true;
    document.head.appendChild(hcdeTknService);
     
    let satelliteScript = document.createElement('script');
    satelliteScript.setAttribute('src', '//assets.adobedtm.com/e2f8cd116ff52c784c699a7031ef84a705ee0e03/satelliteLib-7fa3624bda56a3da69adbf41e51715cd547aa343-staging.js')
    satelliteScript.async = true;
    document.head.appendChild(satelliteScript);
    
  }

};
</script>
<style scoped>
.siteWidth{width: 990px; margin:auto;}
@media only screen and (max-width: 990px) {
    .siteWidth{ width: 90%}
}
#mainContent{min-height: calc(100vh - 220px);     background-color: #E6E6E6;}
#mainFooter{ height: 80px;}
</style>
<style>
.chi {
  font-family: "Maison Neue Book", "Maison Neue Medium", "Maison Neue Bold", "Maison Neue Extra Bold";
  
}
</style>
