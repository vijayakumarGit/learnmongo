<template>
   <div id="el"></div> 
</template>



<!-- using string template here to work around HTML <option> placement restriction  :options="options"-->
<script type="text/x-template" id="demo-template">
  <div>

    <p>Selected: {{ selected }}</p>
    <PaymentAuthorization  v-model="selected">
     
      <option disabled value="0">Select one</option>
    </PaymentAuthorization>
  </div>
</script>

<script type="text/x-template" id="select2-template">
  <select>
    <slot></slot>
  </select>
</script>


<script>
export default {

  //props: ['options', 'value'],
  template: '#select2-template',
  data() {
    return {
    selected: 2,
    options: [
      { id: 1, text: 'Hello' },
      { id: 2, text: 'World' }
    ]
    }
  },
  mounted: function () {
    var vm = this
    window.$(this.$el)
      // init select2
      .PaymentAuthorization({ data: this.options })
      .val(this.value)
      .trigger('change')
      // emit event on change.
      .on('change', function () {
        vm.$emit('input', this.value)
      })
  },
  watch: {
    value: function (value) {
      // update value
      window.$(this.$el)
      	.val(value)
      	.trigger('change')
    },
    options: function (options) {
      // update options
      window.$(this.$el).empty().PaymentAuthorization({ data: options })
    }
  },
  destroyed: function () {
    window.$(this.$el).off().PaymentAuthorization('destroy')
  }
// };

// var vm = new Vue({
//   el: '#el',
//   template: '#demo-template',
//   data: {
//     selected: 2,
//     options: [
//       { id: 1, text: 'Hello' },
//       { id: 2, text: 'World' }
//     ]
//   }
// })
}
</script>