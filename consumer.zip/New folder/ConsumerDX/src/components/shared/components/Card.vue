<template>

  <div class="a-card">
    <div class="a-card__header -noBorder">
      <h5 class="a-card__title">{{ title }}</h5>
    </div>

    <div v-if="isContentPresent"
      class="a-card__content">
      <slot name="content"></slot>
    </div>

    <div v-if="isFooterPresent"
      class="a-card__footer">
      <slot name="footer"></slot>
    </div>
  </div>

</template>

<script>
export default {
  name: "Card"
  , props: ["title"]
  , components: {}
  , data() {
    return {
    };
  }

  , computed: {
    isContentPresent: function() {
      return !!this.$slots.content;
    }
    , isFooterPresent: function() {
      return !!this.$slots.footer;
    }
  }
  , methods: {}

  , created: function() {}
  , updated: function() {}
  , watch: {}
};
</script>

<style scoped>
.a-card {
  padding: 0rem;
}
</style>