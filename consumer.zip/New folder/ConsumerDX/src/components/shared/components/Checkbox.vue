<template>
  <div class="checkbox">

    <input type="checkbox" class="a-input" :id="id"
      :value="id" :checked="checked" @click="emitSelected">
    <label :for="id"></label>

  </div>
</template>

<script>
export default {
  name: 'Checkbox'
  , props: ['id', 'checked']
  , components: {}
  , data() {
    return {}
  }

  , computed: {}
  , methods: {
    emitSelected: function() {
      this.$emit('click', this.id);
    }
  }
  
}
</script>
<style scoped>
.checkbox label {
  margin-bottom: 0;
}

.checkbox input[type=checkbox].a-input+label:before {
  border: 1px solid var(--carbon-100);
  border-radius: 2.5rem;
  height: 2.5rem;
  width: 2.5rem;
}
.checkbox input[type=checkbox].a-input+label:after {
  height: 1.25rem;
  left: 0.63rem;
  top: 0.63rem;
  width: 1.25rem;
}

.checkbox input[type=checkbox].a-input:checked+label:before {
  background-color: var(--white);
  border: 1px solid var(--green-500);
}
.checkbox input[type=checkbox].a-input:checked+label:after {
  background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg viewBox='0 0 16 16' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M16 4.43L5.29 14.8l-.074-.082-2.105-2.346L0 8.907l2.304-2.23 3.11 3.464L13.82 2 16 4.43' fill='%2300853f' fill-rule='evenodd'/%3E%3C/svg%3E")
}

</style>