<template>

    <div class="list">

      <div v-if="isHeaderPresent"
        class="list__header">
        <slot name="header"></slot>
      </div>

      <div v-if="searchField" class="a-inputWrapper -iconLeft -iconRight list--search">
        <input type="text" class="a-input" placeholder="Search" v-model="searchFilter">
        <div class="a-icon">
          <i class='fal fa-search'></i></div>
      </div>

      <ul class="list__container a-tabs -vertical -large">
        <slot v-for="element in listFiltered" :row="element"></slot>
      </ul>

      <div v-if="isFooterPresent"
        class="list__footer">
        <slot name="footer"></slot>
      </div>

    </div>

</template>

<script>
export default {
  name: 'List'
  , props: ['searchField', 'list']
  , components: {}
  , data() {
    return {
      searchFilter: ''
    }
  }

  , computed: {
    listFiltered() {
      let searchFilters = (this.searchField || '').split('.');

      return (!!this.searchField && !!this.list) ? this.list.filter(element => {
        let finalElement = element[searchFilters[0]] || '';
        let i = 1;

        while (i < searchFilters.length) {
          finalElement = finalElement[searchFilters[i]];
          i += 1;
        }

        return finalElement.toLowerCase().includes(this.searchFilter.toLowerCase());

      }) : this.list;
    }
    , isHeaderPresent() {
      return !!this.$slots.header;
    }
    , isFooterPresent() {
      return !!this.$slots.footer;
    }
  }
  , methods: {}

}
</script>

<style scoped>
.list {
  align-items: center;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  width: 100%;
}
.list__header {
  width: 100%;
}
.list--search {
  margin: 1.5rem 0;
}
.list__container {
  height: 100%;
  overflow-y: auto;
  width: 100%;
}
.list__container li>a {
  font-weight: normal;
}
.list__container li.-active>a {
  font-weight: 600;
}
.list__footer {
  width: 100%;
}

::-webkit-scrollbar {
    width: 0.5rem;
}
::-webkit-scrollbar-thumb {
    background-color: var(--grey-600); 
    border-radius: 7px;
}
</style>
