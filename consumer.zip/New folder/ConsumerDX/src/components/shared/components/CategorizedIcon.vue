<template>
  <span class="fa-layers" :class="getSize" :key="getCategory">
    <i class="fas fa-circle" :class="getSize" :style="getColor" />
    <span class="fa-layers-text fa-inverse category" :class="getSize">
      {{ getCategory }}
    </span>
  </span>
</template>

<script>
export default {
  name: 'CategorizedIcon'
  , props: ['category', 'size']
  , data() {
    return {
    }
  }

  , computed: {
    getSize() {
      let size = this.size || 'l';

      return [size];
    }
    , getColor() {
      return { color: '#' + this.intToARGB(this.hashCode(this.category)) };
    }
    , getCategory() {
      return !!this.category && this.category.length > 0 ? this.category[0] : '';
    }
  }
  , methods: {
    hashCode: function(str) {
      var hash = 0;
      for (var i = 0; i < str.length; i++) {
          hash = str.charCodeAt(i) + ((hash << 5) - hash);
      }
      return hash;
    }
    , intToARGB: function(i) {
      var hex = ((i>>24)&0xFF).toString(16)
        + ((i>>16)&0xFF).toString(16)
        + ((i>>8)&0xFF).toString(16)
        + (i&0xFF).toString(16);
      hex += '000000';

      return hex.substring(0, 6);
    }
  }
}
</script>

<style scoped>
img {
  border-radius: 50%;
}
.xl {
  height: 3.13rem;
  min-width: 3.13rem;
  line-height: 3.13rem;
  width: 3.13rem;
}
.l {
  height: 2rem;
  min-width: 2rem;
  line-height: 2rem;
  width: 2rem;
}
.category {
  font-weight: 600;
  text-align: center;
}
</style>
