<template>

    <div ref="modalDialog">

      <div class="a-modal__header sh-layout__header" :class="{ '-noBorder' : !showBorderHeader }">

        <nav  v-if="(typeof showMenu==='undefined') || (showMenu===true)" class="navbar navbar-expand-md navbar-light">
          <button class="navbar-toggler" type="button" ref="navbarToggler"
            data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
        </nav>

        <div class="sh-layout__title">
          <slot name="title"></slot>
        </div>
        <button class="sh-layout__close"
          v-if="showCloseButton" @click="closeModal">
          <i class="fal fa-times sh-layout__close--icon"></i>
          </button>
      </div>

      <div class="a-modal__content sh-layout__content">

        <nav class="modal-menu navbar navbar-expand-md navbar-light" :class="{'float': $parent.isMenuVertical}">  
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <slot name="menu"></slot>
          </div>
        </nav>

        <slot name="body"></slot>
      </div>

      <div class="sh-layout__footer"
        v-if="showFooter">
        <slot name="footer"></slot>
      </div>

    </div>

</template>

<script>

export default {
  name: 'Layout'
  , props: ['showBorderHeader', 'showCloseButton', 'showFooter', 'showMenu']
  , components: {}

  , data() { 
    return {}
  }

  , computed: {}
  , methods: {
    closeModal: function() {
      this.$parent.$emit('close');
    }
    , adjustMenuWidth: function(){
      var menu = document.getElementById ("navbarSupportedContent");
      var dialogStyle = window.getComputedStyle(this.$refs.modalDialog);
      menu.style.width = (dialogStyle.width);
    }
    , detectCollapsible: function(){
      if (this.showMenu===false){
        return;  //do nothing if menu is not displayed
      }
      var style = window.getComputedStyle (this.$refs.navbarToggler);
      var isCollapsible = style.display != 'none';
      this.$emit("collapsible-navbar", isCollapsible);
      if (isCollapsible) {
        this.adjustMenuWidth();
      }
    }
  }
  , created: function() {}
  , mounted: function () {
      this.detectCollapsible();
      window.addEventListener('resize', this.detectCollapsible);
    }
  , beforeDestroy: function() {
      window.removeEventListener('resize', this.detectCollapsible);
    }
  , watch: {}
  , destroyed: function() {}
}
</script>

<style scoped>
.sh-layout__header {
  align-items: center;
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
}
.sh-layout__title {
  color: var(--carbon-500);
  font-size: 24px;
  font-weight: 300;
  margin: auto;
}
.sh-layout__close {
  background-color: transparent;
  border: 0px;
  box-sizing: border-box;
  cursor: pointer;
  height: 24px;
  padding: 0px;
}
.sh-layout__close--icon {
  color: var(--carbon-500);
  font-size: 24px;
  width: 24px;
}
.modal-menu {
  padding: 0px;
}
.sh-layout__content {
  height: 100%;
  padding: 0px;
}
.sh-layout__footer {
  background-color: var(--grey-300);
}
.float {
  position: absolute;
  background: #fff;
  z-index: 20;
  padding: 0px;
}
</style>