<template>

  <div class="categorized-list__container">
    <div v-for="category in categories" :key="category">

      <div class="categorized-list__row">
        <div class="fa-layers categorized-list__category__icon">
          <i class="fal fa-circle"></i>
          <span class="fa-layers-text categorized-list__category__icon--description">{{ category }}</span>
        </div>
        <div class="categorized-list__category__line"></div>
      </div>

      <slot v-for="element in getElementsByCategory(category)"
        :item="element"></slot>

    </div>
  </div>

</template>

<script>

export default {
    name: 'CategorizedList'
    , props: ['list', 'categories', 'howtocategorize']
    , components: {
    }
    , data() {
      return {
      }        
    }

    , computed: {}
    , methods:{      
      getElementsByCategory: function(category) {
        return this.list.filter(element => this.howtocategorize(element, category));
      }
    }

    , created: function() {}
    , updated: function() {}
    , watch: {}
}
</script>

<style scoped>
.categorized-list {
  align-items: center;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  width: 100%;
}
.categorized-list__row {
  align-items: center;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  padding: 0.75rem 0;
  width: 100%;
}
.categorized-list__category__icon {
  height: 2rem;
  min-width: 2rem;  
}
.categorized-list__category__icon svg {
  color: var(--carbon-100);
  height: 2rem;
  width: 2rem;
}
.categorized-list__category__icon--description {
  font-weight: 600;
  height: 2rem;
  line-height: 2rem;
  text-align: center;
  width: 2rem;
}
.categorized-list__category__line {
  border-top: 1px solid var(--grey-500);
  margin-right: 2.5rem;
  width: 100%;
}

::-webkit-scrollbar {
  width: 0.5rem;
}
::-webkit-scrollbar-thumb {
  background-color: var(--grey-600); 
  border-radius: 7px;
}
</style>