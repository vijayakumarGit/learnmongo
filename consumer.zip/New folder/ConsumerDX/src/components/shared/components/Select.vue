<template>

  <div id="select">
    <div class="wrapper-dropdown" :class="getWidthOpen">{{ getSelected || name }}

      <div class="dropdown-container" :class="getWidth">
        <div class="dropdown-scroll">
          <ul class="dropdown">

            <li
              v-if="!multiselect"
              v-for="item in list" :key="item" :ref="'ms-ref-' + item" :id="item"
              @click.stop.prevent="selectOption('ms-ref-' + item)"
              :class="{ 'selected' : selected === item }">

              <slot :row="item"></slot>
            </li>

            <li
              v-if="multiselect"
              v-for="item in list" :key="item" :ref="'ms-ref-' + item" :id="item"
              @click.stop.prevent="selectOption('ms-ref-' + item)"
              class="a-formGroup dropdown-option">

              <input type="checkbox" class="a-input"
                :id="item+'-checkbox'" :checked="checked[item]" :value="item">
              <label :for="item+'-checkbox'" ></label>
              <div :for="item+'-checkbox'">
                <slot :row="item"></slot>
              </div>
            </li>

          </ul>
        </div>
      </div>
  
    </div>
  </div>

</template>
<script>
export default {
  name: "Select"
  , props: ["name", "list", "selected", "width", "multiselect"]
  , components: {
  }
  , data() {
    return {
      isOpen: false
    }
  }

  , computed: {
    getWidth() {
      let width = this.width || 'medium';

      return [width];
    }
    , getWidthOpen() {
      return this.getWidth.concat(this.isOpen ? ['open'] : []);
    }
    , getSelected() {
      return this.multiselect ? (!!this.selected ? this.selected.join(', ') : '') : this.selected;
    }
    , checked() {
      let checked = {};

      if (!!this.multiselect) {
        for (let index in this.list) {
          checked[this.list[index]] = !!this.selected && this.selected.includes(this.list[index]) ? true : false;
        }
      }
      return checked;
    }
  }
  , methods: {
      selectOption: function(element) {
        if (!!element && !!this.$refs[element] && this.$refs[element].length > 0) {
          this.$emit('select', this.$refs[element][0].id);

          if (!this.multiselect) {
            this.handleOpen(element);
          }
        }
      }
      , handleOpen: function(element) {
        if (this.$el !== element.target && !this.$el.contains(element.target)) {
          this.isOpen = false;
        } else {
          this.isOpen = !this.isOpen;
        }
      }
  }

  , created: function() {
      document.addEventListener('click', this.handleOpen);
      document.addEventListener('keydown', event => {
        if (event.key === 'Escape' || event.keyCode === 27) {
          this.handleOpen(event);
        }
      });
  }
  , mounted: function() {
      let elements = this.$el.querySelectorAll('.dropdown-scroll ul li');

      if (!!this.selected && this.selected.length > 0 && !!elements && elements.length > 0) {
        let index = 0;
        let selectedFound = false;

        while (index < elements.length && !selectedFound) {
          if (elements[index].id === this.selected || (this.selected.length > 0 && elements[index].id === this.selected[0])) {
            selectedFound = true;
          }
          index++;
        }
        index--;
        this.$el.querySelector('.dropdown-scroll').scrollTop = index * elements[index].offsetHeight;
      }
  }
  , updated: function() {}
  , watch: {}

  , destroyed: function() {
    document.removeEventListener('click', this.handleOpen);
    document.removeEventListener('keydown', event => {
      if (event.key === 'Escape' || event.keyCode === 27) {
        this.handleOpen(event);
      }
    });
  }
}
</script>
<style scoped>
.wrapper-dropdown {
    border: 0.06rem solid var(--grey-600);
    border-radius: 3px;
    color: var(--carbon-200);
    cursor: pointer;
    font-size: 0.81rem;
    height: 2rem;
    line-height: 2rem;
    outline: none;
    padding-left: 0.75rem;
    padding-right: 1.69rem;
    position: relative;
}
.wrapper-dropdown:after {
    border-width: 6px 6px 0 6px;
    border-style: solid;
    border-color: var(--carbon-500) transparent;
    content: "";
    height: 0;
    margin-top: -3px;
    position: absolute;
    right: 0.5rem;
    top: 50%;
    width: 0;
}
.wrapper-dropdown.open:after {
    border-width: 0 6px 6px 6px;
}
.wrapper-dropdown.open .dropdown-container {
    opacity: 1;
    pointer-events: auto;
}
.small {
    width: 7rem;
}
.medium {
    width: 14rem;
}
.large {
    width: 18rem;
}

.xlarge {
    width: 25rem;
}

.dropdown-container {
    background: var(--white);
    border: 0.06rem solid var(--grey-600);
    left: -1px;
    opacity: 0;
    padding-bottom: 0.5rem;
    padding-right: 0.5rem;
    padding-top: 0.5rem;
    pointer-events: none;
    position: absolute;
    right: 0;
    top: 100%;
    z-index: 1;
}
.dropdown-container .dropdown-scroll {
    max-height: 7.5rem;
    overflow: hidden;
    overflow-y: auto;
}
.dropdown-container .dropdown {
    list-style: none;
    margin: 0;
    padding: 0;
}
.dropdown-container .dropdown li {
    cursor: pointer;
    display: block;
    font-size: 0.7rem;
    line-height: 1.5rem;
    padding-left: 2rem;
    padding-right: 0.5rem;
    text-decoration: none;
}
.dropdown-container .dropdown li:hover {
    background-color: var(--grey-300);
}

.dropdown-container .dropdown li.selected {
    background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg viewBox='0 0 16 16' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M16 4.43L5.29 14.8l-.074-.082-2.105-2.346L0 8.907l2.304-2.23 3.11 3.464L13.82 2 16 4.43' fill='%2334B233' fill-rule='evenodd'/%3E%3C/svg%3E");
    background-position: 0.5rem center;
    background-repeat: no-repeat;
    background-size: 1rem 1rem;
}

.dropdown-container .dropdown li.dropdown-option {
    align-items: center;
    display: flex;
    flex-direction: row;
    justify-content: flex-start;
}
.dropdown-container .dropdown li.dropdown-option label{
    margin-bottom: 0rem;
    margin-left: -1.25rem;
    margin-right: 0.5rem;
}

::-webkit-scrollbar {
    width: 0.5rem;
}
::-webkit-scrollbar-thumb {
    background-color: var(--grey-600); 
    border-radius: 7px;
}
</style>
