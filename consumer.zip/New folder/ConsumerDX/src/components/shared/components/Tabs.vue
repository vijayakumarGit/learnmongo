<template>

  <div class="-bb1 -d--flex -justify-content--center">
    <div v-show="!this.vertical"></div>
    <ul class="a-tabs" :class="{ '-vertical': this.vertical }" ref="tabsCursor">
      <li :class="{ '-active': activeTab() === option }"
        v-for="option in options"
        :key="option"><a @click="showContent(option)" data-toggle="collapse" data-target=".navbar-collapse.show">{{ option }}</a></li>
    </ul>
  </div>

</template>
<script>

export default {
  name: "Tabs"
  , props: ["options", "active", "vertical"]
  , components: {}
  , data() {
    return {
      oldActive: null
    };
  }
  , computed: {}
  , methods: {
    activeTab: function() {
      if (!!this.active) {
        //console.log("1 returning: " + this.active);
        return this.active;
      }
      if (!!this.options && this.options.length > 0) {
        //console.log("2 returning: " + this.options[0]);
        return this.options[0];
      }
      //console.log("1 returning empty string" );
      return '';
    },
    activeTabIndex: function(val) {
      if (!!this.active) {
        return this.options.indexOf(val);
        //console.log("1 returning: " + this.active);
        //return this.active;
      }
      if (!!this.options && this.options.length > 0) {
        //console.log("2 returning: " + this.options[0]);
        return this.options[0];
      }
      //console.log("1 returning empty string" );
      return '';
    }
    , showContent: function(option) {
      this.$emit("click", option);
      if(option === "Change Home Phone"){
        //option = "Add Home Phone";
      }
    }
  }
  , created: function() {}
  , updated: function() {
      this.oldActive = this.active;
  }
  , mounted: function () {
      chiTabs.init(this.$refs.tabsCursor);
      this.oldActive = this.active;
   }
  , watch: {}
};
</script>

<style scoped>
.a-tabs:not(.-vertical) {
	height: auto;
}
.chi .a-tabs:not(.-vertical) > li.-active > a{
  border: none;
}

.chi .a-tabs.-vertical.-border > li:first-child > a,
.chi .a-tabs.-vertical.-border > li > a {
  padding-bottom: .75rem;
  padding-top: .75rem;
}
.chi .a-tabs.-vertical:not(.a-tabs--js)>li.-active>a:before {
  height: 2.57rem;
}
</style>