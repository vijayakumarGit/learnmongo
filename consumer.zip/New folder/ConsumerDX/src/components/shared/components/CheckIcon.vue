<template>
  <div :class="getSize" :key="selected">
    <i v-if="!selected" class="fal fa-circle" :class="getCircleSizeColor"></i>
    <i v-else class="fas fa-check-circle" :class="getCheckSizeColor"></i>
  </div>
</template>

<script>
import moment from "moment";

export default {
  name: 'CheckIcon'
  , props: ['selected', 'size']
  , components: {
  }
  , data() {
    return {
    }
  }
  , computed: {
    getSize() {
      let size = this.size || 'l';

      return [size];
    }
    , getCircleSizeColor() {
      let color = 'light';

      return [color].concat(this.getSize);
    }
    , getCheckSizeColor() {
      let color = 'mint-green';

      return [color].concat(this.getSize);
    }
  }
}
</script>
<style scoped>
.light {
  color: var(--md-gray);
}
.mint-green {
  color: var(--mint-green);
}
.xl {
  height: 3rem;
  width: 3rem;
}
.l {
  height: 2rem;
  width: 2rem;
}
.m {
  height: 1.5rem;
  width: 1.5rem;
}
</style>