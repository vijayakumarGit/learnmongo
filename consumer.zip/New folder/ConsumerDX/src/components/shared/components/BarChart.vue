<template>
    <canvas :height="config.height" :width="config.width" ref="chart"></canvas>
</template>

<script>
import Chart from 'chart.js';

export default {
  name: 'BarChart'
  , props: ['config', 'data']
  , components: {
  }
  , data() {
    return {
      chart: null
      , chartColor: { r: 160, g: 221, b: 76 }
    }
  }

  , computed: {
      usageData() {
        let usage = {
          type: 'bar'
          , data: {
            labels: []
            , datasets: [{
              data: []
              , backgroundColor: []
            }]
          }
          , options: {
            tooltips: {
              enabled: true ,
            },
            layout: {
              padding: {
                top: !!this.config.padding ? this.config.padding.top : 0
                , right: !!this.config.padding ? this.config.padding.right : 0
                , bottom: !!this.config.padding ? this.config.padding.bottom : 0
                , left: !!this.config.padding ? this.config.padding.left : 0
              }
            }
            , legend: {
              display: false
            }
            , scales: {
              xAxes: [{
                barPercentage: 0.8
                , categoryPercentage: 0.7
                , ticks: {
                  fontSize: this.config.fontSizeTicks || 11
                  , fontStyle: '600'
                  , fontFamily: 'Open Sans'
                }
                , gridLines: {
                  color: 'rgba(0, 0, 0, 0)'
                }
              }]
              , yAxes: [{
                ticks: {
                  beginAtZero: true
                  , maxTicksLimit: 4
                  , fontSize: (this.config.fontSizeTicks || 11) * 0.82
                  , fontStyle: '600'
                  , fontFamily: 'Open Sans'
                  , callback: this.config.ticks
                }
                , gridLines: {
                  display: false
                }
              }]
            }
          }
        }
        usage.data.labels = [ ...this.data.labels ];

        if (!!this.data.dataset && this.data.dataset.length > 0) {
          usage.data.datasets[0].data = [ ...this.data.dataset ];

          for (let i in this.data.dataset) {
            usage.data.datasets[0].backgroundColor.push('rgba(' + Object.values(this.chartColor).join(',') + ',1)');
          }
        }
        
        if (this.config.customTooltip) {
          usage.options.tooltips.enabled = false;
          usage.options.tooltips.custom = this.config.customTooltip;
        }
        return usage;
      }
  }
  , methods: {
  }

  , created: function() {}
  , mounted: function() {
    this.chart = new Chart(this.$refs.chart, {
      type: this.usageData.type,
      data: this.usageData.data,
      options: this.usageData.options,
    });
  }
  , updated: function() {
    if (!!this.chart) {
      this.chart.data = this.usageData.data;
      this.chart.options = this.usageData.options;
      this.chart.update();
    }
  }
  , destroyed: function() {
    !!this.chart && this.chart.destroy();
  }

  , watch: {}
};
</script>

<style scoped>
</style>