<template>
  <img v-if="!!photo" :class="getSize" :src="photo" />

  <span v-else class="fa-stack" :class="getSizeColor" :key="type">
    <i class="fal fa-circle fa-stack-2x" :class="getSizeColor"></i>
    <i class="fal fa-stack-1x" :class="getTypeSizeColor" style="height: 50%; width: 50%;"></i>
  </span>
</template>

<script>
export default {
  name: 'UserIcon'
  , props: ['type', 'photo', 'size', 'color']
  , components: {
  }
  , data() {
    return {
    }
  }
  , computed: {
    getSize() {
      let size = this.size || 'l';

      return [size];
    }
    , getSizeColor() {
      let color = this.color || 'light';

      return [color].concat(this.getSize);
    }
    , getTypeSizeColor() {
      let type = !!this.type ? this.type.toLowerCase() : 'user';

      return ['fa-' + type].concat(this.getSizeColor);
    }
  }
}
</script>
<style scoped>
.light {
  color: var(--carbon-100);
}
.dark {
  color: var(--carbon-500);
}
img {
  border-radius: 50%;
}
.xl3 {
  height: 5rem;
  width: 5rem;
}
.xl2 {
  height: 4rem;
  width: 4rem;
}
.xl {
  height: 3rem;
  width: 3rem;
}
.l {
  height: 2rem;
  width: 2rem;
}
</style>