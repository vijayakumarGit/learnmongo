<template>
  <div :class="getSize" :key="time">
    <i class="fal fa-clock" :class="getSizeColor" :data-fa-transform="getRotation"></i>
  </div>
</template>

<script>
import moment from "moment";

export default {
  name: 'ClockIcon'
  , props: ['time', 'size', 'color']
  , components: {
  }
  , data() {
    return {
    }
  }
  , computed: {
    getSize() {
      let size = this.size || 'l';

      return [size];
    }
    , getSizeColor() {
      let color = this.color || 'light';

      return [color].concat(this.getSize);
    }
    , getRotation() {
      let rotation = !!this.time ? (moment(this.time, 'hh:mm A').hour()-4) * 30 : 0;
      if (rotation > 180) rotation = rotation - 360;

      return 'rotate-' + rotation;
    }
  }
}
</script>
<style scoped>
.light {
  color: var(--carbon-100);
}
.dark {
  color: var(--carbon-500);
}
.xl {
  height: 3rem;
  width: 3rem;
}
.l {
  height: 2rem;
  width: 2rem;
}
</style>