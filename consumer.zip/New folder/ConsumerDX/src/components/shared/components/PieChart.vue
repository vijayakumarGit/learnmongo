<template>
  <canvas :height="config.height" :width="config.width" ref="chart"></canvas>
</template>

<script>
import Chart from 'chart.js';

export default {
  name: 'PieChart'
  , props: ['config', 'data']
  , components: {
  }
  , data() {
    return {
      chart: null
      , chartColors: [
        { r: 160, g: 221, b: 76 }
        ,{ r: 21, g: 231, b: 8 }
      ]
      , backgroundColor: { r: 51, g: 51, b: 51 }
      , bodyFontColor: { r: 250, g: 250, b: 250 }
    }
  }

  , computed: {
      usageData() {
        let usage = {
          type: 'pie'
          , data: {
            labels: []
            , datasets: [{
              data: []
              , backgroundColor: []
              , borderWidth: []
            }]
          }
          , options: {
            layout: {
              padding: {
                top: !!this.config.padding ? this.config.padding.top : 0
                , right: !!this.config.padding ? this.config.padding.right : 0
                , bottom: !!this.config.padding ? this.config.padding.bottom : 0
                , left: !!this.config.padding ? this.config.padding.left : 0
              }
            }
            , title: {
              display: !!this.config.title
              , text: this.config.title
            }
            , legend: {
              display: !!this.config.positionLegend
              , position: this.config.positionLegend
              , labels: {
                boxWidth: 15
              }
            }
            , tooltips: {
              backgroundColor: 'rgba(' + Object.values(this.backgroundColor).join(',') + ',1)'
              , bodyFontColor: 'rgba(' + Object.values(this.bodyFontColor).join(',') + ',1)'
            }
          }
        }
        usage.data.labels = [ ...this.data.labels ];

        if (!!this.data.dataset && this.data.dataset.length > 0) {
          let steps = this.data.dataset.length+1;
          let step = [ [], [], [] ];

          for (let i in this.chartColors) {
            step[0].push(Math.floor(this.chartColors[i].r/steps));
            step[1].push(Math.floor(this.chartColors[i].g/steps));
            step[2].push(Math.floor(this.chartColors[i].b/steps));
          }

          for (let i in this.data.dataset) {
            let j = i - (Math.floor(i/2) * 2);
            let newColor = 'rgba(' + Object.values(this.chartColors[j]).map((color,index) => color - step[index][j] * i).join(',') + ', 1)';

            usage.data.datasets[0].backgroundColor.push(newColor);
            usage.data.datasets[0].borderWidth.push(1);
          }
          usage.data.datasets[0].data = [ ...this.data.dataset ];
        }

        return usage;
      }
  }
  , methods: {
  }

  , created: function() {}
  , mounted: function() {
    this.chart = new Chart(this.$refs.chart, {
      type: this.usageData.type
      , data: this.usageData.data
      , options: this.usageData.options
    });
  }
  , updated: function() {
    if (!!this.chart) {
      this.chart.data = this.usageData.data;
      this.chart.options = this.usageData.options;
      this.chart.update();
    }
  }
  , destroyed: function() {
    !!this.chart && this.chart.destroy();
  }
  , watch: {}
};
</script>

<style scoped>
</style>