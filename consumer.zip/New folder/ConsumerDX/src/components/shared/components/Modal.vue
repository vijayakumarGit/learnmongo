<template>
  <div class="a-modal__backdrop sh-modal__backdrop" id="sh-backdrop">
    <div class="a-modal sh-modal">
      <div class="a-modal__header sh-modal__header" :class="{ '-noBorder' : !showBorderHeader }">
        <div class="sh-modal__title">
          <slot name="title"></slot>
        </div>
        <button class="sh-modal__close"
          v-if="showCloseButton" @click="closeModal">
          <i class="fal fa-times sh-modal__close--icon"></i>
          </button>
      </div>
      <div class="a-modal__content sh-modal__content">
        <slot name="body"></slot>
      </div>
      <div class="a-modal__footer sh-modal__footer"
        v-if="showFooter">
        <slot name="footer"></slot>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Modal'
  , props: ['showBorderHeader', 'showCloseButton', 'showFooter']
  , components: {}

  , data() { 
    return {
      isShowFooter: false
    }
  }

  , computed: {}
  , methods: {
    closeModal: function() {
      this.$parent.$emit('close');
    }
  }

  , created: function() {}
  , mounted: function() {}
  , watch: {
    showFooter: function(newVal,oldVal) {
      // console.log("(Modal.vue~watch:showFooter)INIT: newVal=" + JSON.stringify(newVal) + "\n\r  AND oldVal=" + JSON.stringify(oldVal));
      if(newVal!==oldVal) {
        this.isShowFooter = newVal;
      }
      // console.log("(Modal.vue~watch:showFooter)POST: isShowFooter=" + JSON.stringify(this.isShowFooter));
    }
  }
  , destroyed: function() {}
}
</script>

<style scoped>
.sh-modal__backdrop {
  background-color: unset;
  position: relative;
}
.sh-modal {
  box-shadow: 0 0 12px 0 rgba(0,0,0,0.2),
    0 24px 40px 0 rgba(0,0,0,0.3);
  margin-bottom: 50px;
  max-width: 984px;
  min-height: 616px;
  min-width: 984px;
}
.sh-modal__header {
  align-items: center;
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
}
.sh-modal__title {
  color: var(--carbon-500);
  font-size: 24px;
  font-weight: 300;
  margin: auto;
}
.sh-modal__close {
  background-color: transparent;
  border: 0px;
  box-sizing: border-box;
  cursor: pointer;
  height: 24px;
  padding: 0px;
  z-index: 9999;
}
.sh-modal__close--icon {
  color: var(--carbon-500);
  font-size: 24px;
  width: 24px;
  position: absolute;
  top: 15px;
  right: 15px;
}
.sh-modal__content {
  height: 100%;
  padding: 0px;
}
.sh-modal__footer {
  background-color: var(--grey-300);
}
</style>