<template>

  <div class="panel-stack">

    <div class="panel-stack__nav" v-if="!!containers.middle">
        <button class="a-btn -small panel-stack__back" @click="goBack()">
          <i class="fa fa-chevron-left"></i>
          <span>Back</span></button>
    </div>
    <div class="panel-stack__containers">

      <div class="panel-stack__left-container" :class="{ 'panel-stack__hide-panel' : !!containers.middle }">
          <slot name="left-panel" ></slot>
      </div>

      <div class="panel-stack__middle-container" :class="{ 'panel-stack__hide-panel' : !!containers.right || !containers.middle}">
          <slot name="middle-panel" ></slot>
      </div>

      <div class="panel-stack__right-container"
        v-if="!! containers.right">
          <slot name="right-panel" ></slot>
      </div>

    </div>
  </div>

</template>

<script>


export default {
    name: 'PanelStack'
    , props: ['containers', 'constMiddle', 'constRight']
    , components: {
    }
    , data() {
      return {
      }
    }
    , methods:{

     goBack: function () {
        if (!! this.containers[this.constRight]) {
          this.$parent.hideContainer(this.constRight);
        } else if (!! this.containers[this.constMiddle]) {
          this.$parent.hideContainer(this.constMiddle);
        }
      }
    }
    , created: function() {}
    , updated: function() {}
    , watch: {}
}
</script>

<style scoped>
.panel-stack {
  display: block;
  width: 100%;
  height: 100%;
  z-index: 0;
}
.panel-stack__nav {
  padding-top: 1.5rem;
  padding-left: 1.5rem;
}
.panel-stack__back {
  align-items: center;
  display: flex;
  justify-content: center;
}
.panel-stack__back span {
  margin-left: 0.5rem;
}
.panel-stack__containers {
  align-items: center;
  display: flex;
  flex-direction: row;
  justify-content: center;
  width: 100%;
}
.panel-stack__left-container {
  border-right: 1px solid var(--grey-500);
  min-width: 20.5rem;
}

.panel-stack__middle-container {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  min-width: 20.5rem;
  width: 100%;
}
.panel-stack__right-container {
  border-left: 1px solid var(--grey-500);
  min-width: 20.5rem;
  width: 20.5rem;
}

@media only screen and (max-width: 1152px){
    .panel-stack__hide-panel {
        display: none;
    }
    .panel-stack__left-container {
        border-right: none;
        min-width: initial;
        /* width: 100%; */
    }
    .panel-stack__middle-container {
        min-width: initial;
        width: 100%;
    }
    .panel-stack__right-container {
        border-left: none;
        min-width: initial;
        width: 100%;
    }
}

@media only screen and (min-width: 1152px){
    .panel-stack__nav {
        display: none;
    }
}

::-webkit-scrollbar {
    width: 0.5rem;
}
::-webkit-scrollbar-thumb {
    background-color: var(--grey-600); 
    border-radius: 7px;
}
</style>