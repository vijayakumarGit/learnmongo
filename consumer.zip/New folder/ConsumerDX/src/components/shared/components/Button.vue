<template>
    <button
        class="a-btn -brand -d--flex -flex--row -justify-content--center -align-items--center"
        :class="{ '-outline' : getOutline, '-large' : getLarge, '-small' : getSmall }" :style="getWidth"
        :disabled="getDisabled"
        @click="emitEvent()">
        <slot></slot>
    </button>
</template>

<script>
export default {
  name: 'Button'
  , props: ['outline', 'size', 'width', 'disabled']
  , components: {}
  , data() {
    return {
    }
  }

  , computed: {
      getWidth: function() {
          // :root font-size: 16px (by default)
          if (window.outerWidth > (this.width * 16 || 12 * 16)) {
              return 'width: ' + (this.width || 12) + 'rem';
          } else {
              return 'max-width: ' + (this.width || 12) + 'rem';
          }
      }
      , getOutline: function() {
          return this.outline === undefined ? true : this.outline;
      }
      , getLarge: function() {
          return !!this.size && this.size === 'large';
      }
      , getSmall: function() {
          return !!this.size && this.size === 'small';
      }
      , getDisabled: function() {
          return !!this.disabled;
      }
  }
  , methods: {
      emitEvent: function() {
          this.$emit('click');
      }
  }
};
</script>

<style scoped>
.a-btn {
    font-family: "Maison Neue Book", "Maison Neue Medium", "Maison Neue Bold", "Maison Neue Extra Bold";
    font-size: 0.80rem;
    border-radius: 1.5rem;
    white-space: normal;
}
.chi .a-btn.-large {
    border-radius: 2rem;
    line-height: 2;
}
.chi .a-btn.-brand {
    background-color: var(--mint-green);
    border: .0625rem solid var(--mint-green);
    border-color: var(--mint-green);
    color: unset;
    box-shadow: 0 0 0 0;
}
.chi .a-btn.-brand.-outline {
    background-color: var(--mint-green);
    border: .0625rem solid var(--mint-green);
    /* color: var(--mint-green); */
}
.chi .a-btn.-brand:active {
    background-color: var(--mint-green);
    color: var(--white);
}
.chi .a-btn.-brand:hover {
    background-color: var(--mint-green);
    border: .0625rem solid var(--mint-green);
    color: var(--white);
}
.chi .a-btn.-brand.-outline:active {
    background-color: var(--mint-green);
    color: var(--white);
}
.chi .a-btn.-brand.-outline:hover {
    border: .0625rem solid var(--mint-green);
    color: var(--white);
}
.chi .a-btn.-brand.-outline:focus {
    border: .0625rem solid var(--mint-green);
    color: var(--white);
    box-shadow: 0 0 0 0;
}
</style>