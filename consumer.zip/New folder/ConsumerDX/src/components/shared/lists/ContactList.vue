<template>
  <CategorizedList :list="listOrdered" :categories="getCategories" :howtocategorize="categorizeContacts">
    <div slot-scope="row"
      class="contact-list__row"
      @click="emitSelectElment(row.item.id)">
      <UserIcon v-if="!!row.item.photo" :photo="row.item.photo" :size="'l'"></UserIcon>
      <CategorizedIcon v-else :category="row.item.name.display" :size="'l'"></CategorizedIcon>
      <span class="contact-list__name">{{ row.item.name.display }}</span>
    </div>
  </CategorizedList>
</template>

<script>
import CategorizedList from '@/components/shared/components/CategorizedList';
import CategorizedIcon from '@/components/shared/components/CategorizedIcon';
import UserIcon from '@/components/shared/components/UserIcon';

import { CATEGORY_ABC, USER } from '@/mixin';

export default {
  name: 'ContactList'
  , props: ['list']
  , components: {
    CategorizedList
    , CategorizedIcon
    , UserIcon
  }
  , data() {
    return {
      constCategoryABC: CATEGORY_ABC
      , constUser: USER
    }
  }
  , computed: {
      getCategories() {
        return this.constCategoryABC.split('');
      }
      , listOrdered() {
        let ordered = [ ...this.list ];
        return ordered.sort(
          (a,b) => { return a.name.display < b.name.display ? -1 : (a.name.display > b.name.display ? 1 : 0); }
        );
      }
  }
  , methods: {
    getFirstChar: function(item) {
      return !!item && item.name.display.length > 0 ? item.name.display[0] : '';
    }
    , categorizeContacts: function(contact, char) {
      let firtChar = this.getFirstChar(contact);
      return firtChar.toLowerCase() === char.toLowerCase();
    }
    , emitSelectElment: function(elementID) {
      this.$emit('elementselected', elementID);
    }
  }

}
</script>

<style scoped>
.contact-list__row {
  align-items: center;
  cursor: pointer;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  padding: 0.75rem 0;
  width: 100%;
}
.contact-list__name {
  margin-left: 0.5rem;
  width: 100%;
}
</style>
