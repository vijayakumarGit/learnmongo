<template>
    <div id="orderSummary" class="containerDiv">
        <div class="title">
            Order Summary
        </div>
        <div class="subTitles">
            One-Time Charges
        </div>
        
    </div>
</template>

<script>
export default {
    name: 'OrderSummary'
    ,props: [],
    components: {
    }
    , data(){
		return {
		}
    }
}
</script>

<style scoped>
    .containerDiv{
        background: #eee;
        border: 1px solid #ddd;
        border-radius: 0.5em;
        margin-top: 3px;
        background-clip: padding-top;
        box-shadow: 3px 3px 4px #ccc;
    }
    .title{
        font-size: 18px;
        font-weight: bold;
        padding: 15px 0px 10px 10px;
        color: var(--blue);
    }
    .subTitles{
        font-weight: bold;
        color: #000;
        height: 40px;
        padding-left: 15px;
        padding-top: 10px;
        margin-bottom: 10px;
        background-color: var(--mint-green);
    }
    .oneTime{
        font-size: 15px;
        padding: 15px 0px 10px 10px;
    }
    
</style>
