<template>
    <div class="offers__layout">
        <div class="-d--flex -flex--column -align-items--start"
            v-if="havePrice">

            <div class="-d--flex -flex--row -flex--wrap -flex-offers-xs--column">

                <div v-for="item in productOffers" :key="item.skuName"
                    class="-mt4 -flex-offers-xs--item a-card -justify-content--between -align-items--center"
                    :class="{ 'offers--selected-product' : isSelectedProduct && item.skuName === selectedName}"
                    @click="pickedSpeed(item)">

                    <div class="-d--flex -flex--column -align-items--center">
                        <span class="offers__text--up-to">Up to</span>
                        <div class="offers__text-speed">
                            {{ getNumber(item.downloadDisplaySpeed) }}<span class="offers__text-speed--units">{{ getUnits(item.downloadDisplaySpeed) }}</span>
                        </div>
                        <div class="offers__advanced-fiber">
                            <img v-if="item.internetType.search('GPON') !== -1" src="/static/img/advanced-fiber-logo.png" />
                        </div>
                        <p class="offers__text--description -d--flex -flex--column -align-content--center">
                            <span v-for="description in speedDescription[item.downloadDisplaySpeed]" :key="description">{{ description }}</span></p>
                    </div>
                    <div class="-d--flex -flex--column -align-items--center"> 
                        <span class="offers__text--no-contract">Price For Life. No Contract.</span>
                        <div class="-d--flex -flex--row offers__text-price">
                            <span class="-align-self--start offers__text-price--dollar">$</span>
                            <div class="-align-self--center offers__text-price--number">
                                {{ (pricesByTier[item.tier].haveDiscount && (!pricesByTier[item.tier].startOn || Date.now() >= pricesByTier[item.tier].startOn))
                                    ? pricesByTier[item.tier].discount
                                    : pricesByTier[item.tier].regular }}</div>
                            <span class="-align-self--end offers__text-price--month">/MO</span>

                            <div class="offers__cross-out offers__price-before -d--flex"
                                v-if="pricesByTier[item.tier].haveDiscount && (!pricesByTier[item.tier].startOn || Date.now() >= pricesByTier[item.tier].startOn)">
                                <span class="-align-self--start offers__price-before--dollar">$</span>
                                <span class="-align-self--center">{{ pricesByTier[item.tier].regular }}</span>
                            </div>

                        </div>
                        <div class="offers__text--install">
                            <div class="-d--flex -flex--row -justify-content--center"
                                v-if="showInstallContent">
                                <span>{{ (!!installContent[item.downloadDisplaySpeed] && !!installContent[item.downloadDisplaySpeed][item.type] && installContent[item.downloadDisplaySpeed][item.type][0])
                                        || installContent.other[0] }}</span>
                                <div class="offers__hover--install -d--flex -justify-content--center">
                                    <img src="/static/img/icon_info.svg" />
                                    <span>{{ (!!installContent[item.downloadDisplaySpeed] && !!!!installContent[item.downloadDisplaySpeed][item.type] && installContent[item.downloadDisplaySpeed][item.type][1])
                                            || installContent.other[1] }}</span>
                                </div>
                            </div>
                        </div>
                        <div class="offers__online">
                            <div class="-d--flex -align-items--center"
                                v-if="!!onlineOffers[item.downloadDisplaySpeed] && Date.now() >= onlineOffers[item.downloadDisplaySpeed].startOn">
                                <svg class="offers__online__line" viewBox="0 0 50 1" preserveAspectRatio="xMidYMid meet">
                                    <rect width="50" height="1" class="offers__line--blue" />
                                </svg>
                                <span>Online Only Offer</span>
                                <svg class="offers__online__line" viewBox="0 0 50 1" preserveAspectRatio="xMidYMid meet">
                                    <rect width="50" height="1" class="offers__line--blue" />
                                </svg>
                            </div>
                        </div>
                        <div class="-d--flex -flex--column -align-items--center offers__text--rate">
                            <span>Prepay required. Rate excludes taxes.</span>
                            <span><a href="https://www.centurylink.com/home/hidden/modals/offer-product-details.html#high_speed_internet in an overlay/modal">Offer Details</a></span>
                        </div>
                    </div>

                    <Button :outline="false" width="9" @click="pickedSpeed(item)">Get {{ item.downloadDisplaySpeed }}</Button>
                </div>

            </div>
        </div>

        <div v-else>
            <div class="-textCenter -mt2">
                <div class="a-grid -p2 offers--no-price">                    
                    <div class="a-col -sm--w12 text-warning">
                        <i class="fal fa-info-circle fa-3x"></i>
                    </div>
                    <div class="a-col -sm--w12">
                        <p class="-textLarge">We hate to say it, but CenturyLink High-Speed Internet is not currently available at your address. 
                            We may have some other Internet options for you though. Please contact us at <span class="-textBrand -textBold">866-541-3322</span> for more 
                            information on plans and pricing.</p>
                        <p class="-textLarge text-info">Try entering another address above!</p>
                    </div>
                </div>
            </div>
        </div>

    </div>    
</template>

<script>
import Button from '@/components/shared/components/Button';

export default {
    name: 'Offers'
    , props: ['speedFromSimulation']
    , components: {
        Button
    }
    , data(){
		return {
            isSelectedProduct: false
            , isActive: false
            , selectedName: ''
            , objOrder: null
		}
    },
    methods: {
		pickedSpeed: function(offer) {
            let speed = { ...{}, ...offer };
            delete speed['type'];

			this.isSelectedProduct = true;
			this.isActive = !this.isActive;
            this.$store.dispatch('setSelectedOffer', speed);
            sessionStorage.setItem("selectedSpeed", JSON.stringify(speed));
            this.selectedName = speed.skuName;
            // this.$emit("isPlanSelected",true);
            //this.$emit("selectedSpeed",speed.downloadDisplaySpeed);
            this.$emit("selectedSpeed",speed);
            // doing this to save the information to pass to the proceedToCheckout
            var objOrder = this.$store.getters.order;
            objOrder.orderStatus = 'inprocess';	
            objOrder.internet.package = speed.skuName;
            objOrder.internet.packageDescription = speed.downloadDisplaySpeed;
            var name = speed.transportUsoc.replace( ";" , "," );
            objOrder.internet.skuNames = name;
            objOrder.internet.price = this.pricesByTier[speed.tier].haveDiscount ? this.pricesByTier[speed.tier].discount : this.pricesByTier[speed.tier].regular;
            objOrder.internet.status = "inprocess";
			var jstring = JSON.stringify(objOrder);
            this.$store.dispatch("updateOrderAll",jstring);
		}
        , getNumber: function(speed) {
            return !!speed && speed.split(' ')[0];
        }
        , getUnits: function(speed) {
            return !!speed && speed.split(' ')[1];
        }
    },
    computed: {
		productOffers() {
            let offersByTier = {};
            let offersPBByTier = {};
            let offersToShow = [];
            let offers = this.$store.getters.getOffers;

            if (!!offers && offers.length > 0 && !!offers[0].offers && offers[0].offers.length > 0) {
                offers[0].offers.forEach(offer => {
                    if (offer.downloadDisplaySpeed !== '4 Mbps') {
                        if (offer.internetType.search('PB') === -1) {
                            if (!offersByTier[offer.tier] || offersByTier[offer.tier].downloadSpeed < offer.downloadSpeed) {
                                offersByTier[offer.tier] = { ...{}, ...offer };
                                offersByTier[offer.tier]['type'] = offer.internetType.search('GPON') !== -1 ? 'GPON' : '';
                            }

                        } else {
                            if (!offersPBByTier[offer.tier] || offersPBByTier[offer.tier].downloadSpeed < offer.downloadSpeed) {
                                offersPBByTier[offer.tier] = { ...{}, ...offer };
                                offersPBByTier[offer.tier]['type'] = 'PB';
                            }
                        }
                    }

                });
            }

            for (let tier=4; tier>0; tier--) {
                if (!!offersPBByTier[tier] && !!offersByTier[tier]) {

                    if (offersPBByTier[tier].downloadSpeed >= offersByTier[tier].downloadSpeed) {
                        offersToShow.push(offersPBByTier[tier]);
                    }
                    offersToShow.push(offersByTier[tier]);

                } else if (!!offersPBByTier[tier] || !!offersByTier[tier]) {
                    offersToShow.push(!!offersPBByTier[tier] ? offersPBByTier[tier] : offersByTier[tier]);
                }

                if (tier === 4 && offersToShow.length > 0) break;
            }

            return offersToShow.length > 4 ? offersToShow.slice(0,4) : offersToShow;
        },
        havePrice() {    
            var offersObj = this.$store.getters.getOffers;

            if (!!offersObj && offersObj.length > 0 && !!offersObj[0].offers && offersObj[0].offers.length > 0 && offersObj[0].offers[0].price > 0) {
                return true;
            }
            return false;
        },
        haveAnOffer() {
            if (this.productOffers.length > 0){
                return true;
            }
            return false;
        }
        , speedDescription() {
            return this.$store.getters.getSpeedDescription;
        }
        , pricesByTier() {
            return this.$store.getters.getPricesByTier;
        }
        , installContent() {
            return this.$store.getters.getInstallContent;
        }
        , showInstallContent() {
            let sameInstallContent = true;

            for (let i=this.productOffers.length-1; i>0; i--) {
                let installTitleFirst = (!!this.installContent[this.productOffers[i].downloadDisplaySpeed]
                    && !!this.installContent[this.productOffers[i].downloadDisplaySpeed][this.productOffers[i].type]
                    && this.installContent[this.productOffers[i].downloadDisplaySpeed][this.productOffers[i].type][0]) || this.installContent.other[0];
                let installTitleSecond = (!!this.installContent[this.productOffers[i-1].downloadDisplaySpeed]
                    && !!this.installContent[this.productOffers[i-1].downloadDisplaySpeed][this.productOffers[i-1].type]
                    && this.installContent[this.productOffers[i-1].downloadDisplaySpeed][this.productOffers[i-1].type][0]) || this.installContent.other[0];

                if (installTitleFirst !== installTitleSecond) {
                    sameInstallContent = false;
                    break;
                }
            }

            return !sameInstallContent;
        }
        , onlineOffers() {
            return this.$store.getters.getOnlineOffers;
        }
    },
    created: function(){
        if(this.speedFromSimulation){
            let obj = this.productOffers.find(obj => obj.downloadDisplaySpeed === this.speedFromSimulation);
            if (obj){
                this.pickedSpeed(obj);
            }
        }

		//this will be used in the proceedToCheckout
		this.objOrder = this.$store.getters.order;
    }
}
</script>

<style scoped>
.offers__layout {
    line-height: normal;
    max-width: 61.875rem;
    margin: auto;
}
.a-card {
    border-radius: 1rem;
    box-shadow: 0.1rem 0.1rem 0.5rem var(--dk-gray);
    font-family: "Maison Neue Book", "Maison Neue Medium", "Maison Neue Bold", "Maison Neue Extra Bold";
    max-width: 18.125rem;
    min-width: 18.125rem;
    padding: 1rem 1rem 1.5rem 1rem;
    width: 18.125rem;
}
.offers--selected-product {
    border: 2px solid var(--mint-green);
    background-color: var(--white);
    box-shadow: 0 1px 2px 0 var(--carbon-500);
}

.offers__text--up-to {
    color: var(--dk-gray);
    font-size: 18px;
    font-weight: 600;
}
.offers__text-speed {
    color: var(--blue);
    font-size: 43px;
}
.offers__text-speed--units {
    font-size: 32px;
    margin-left: 0.4rem;
}
.offers__advanced-fiber {
    height: 1.3rem;
    margin-top: 0.5rem;
}
.offers__advanced-fiber img {
    height: 1.3rem;
    width: auto;
}
.offers__text--description {
    color: var(--dk-gray);
    font-size: 14px;
    line-height: normal;
    margin: 0.8rem 0;
    text-align: center;
}
.offers__text--no-contract {
    border-top: 2px solid var(--mint-green);
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 1rem;
    padding: 0.5rem;
}
.offers__text-price {
    color: var(--dk-gray);
    line-height: 60px;
    margin-bottom: 0.5rem;
    position: relative;
}
.offers__text-price--dollar {
    font-size: 30px;
    line-height: normal;
    padding-top: 0.25rem;
}
.offers__text-price--number {
    font-size: 70px;
}
.offers__text-price--month {
    color: var(--md-gray);
    font-size: 15px;
    line-height: normal;
    padding-bottom: 0.25rem;
}
.offers__price-before {
    bottom: 0;
    font-size: 30px;
    line-height: 25px;
    padding: 0 2px;
    position: absolute;
    right: -53px;
    width: 52px;
}
.offers__price-before span {
    color: var(--blue);
}
.offers__price-before--dollar {
    font-size: 15px;
    line-height: normal;
}
.offers__cross-out {
    background: linear-gradient(to left top, transparent 45.75%, currentColor 48.5%, currentColor 51.5%, transparent 54.25%);
    color: var(--mint-green);
}
.offers__text--install {
    color: var(--dk-gray);
    font-size: 14px;
    width: 100%;
}
.offers__hover--install {
    height: 16px;
    position: relative;
}
.offers__hover--install img {
    margin-left: 0.25rem;
    height: 16px;
    width: auto;
}
.offers__hover--install span {
    background-color: var(--white);
    border: 1px solid var(--md-gray);
    border-radius: 1rem;
    display: none;
    left: -1.5rem;
    padding: 0.5rem;
    position: absolute;
    top: 1.5rem;
    width: 12rem;
    z-index: 1;
}
.offers__hover--install:hover span {
    display: block;

}
.offers__online {
    color: var(--blue);
    font-size: 12px;
    height: 25px;
}
.offers__online div {
    height: 100%;
    width: 100%;
}
.offers__online div span {
    padding: 0.5rem;
}
.offers__online__line {
    max-width: 50px;
    width: 50px;
}
.offers__text--rate {
    color: var(--md-gray);
    font-size: 10px;
    line-height: normal;
    margin-bottom: 1rem;
}
.offers__text--rate a {
    color: var(--navy-blue);
    text-decoration: underline;
}
.offers--no-price {
    border: 2px solid var(--lt-gray);
    background: var(--white);
    box-shadow: 0 10px 20px 2px var(--grey-500);
}

@media only screen and (min-width: 780px) {
    .-flex-offers-xs--item {
        flex-basis: 50%;
    }
    .a-card:not(:last-child) {
        margin-right: 3.75rem;
    }
}
@media only screen and (max-width: 780px) {
    .-flex-offers-xs--column {
        flex-direction: column;
    }
    .a-card:not(:last-child) {
        margin-bottom: 1rem;
    }
}
</style>

