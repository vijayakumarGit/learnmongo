<template>
<div id="responsive-footer" class="container a-grid -no-gutters">
    <div class="a-col -w3 -alignCenter ">
        <p class="sml-logo"><span class="sr-only">CenturyLink Logo</span></p>    
    </div>
    <div class="footer-new a-col -w9">
        
        <!--mp_global_switch_ends-->
        <span class="tablet_hide fullscreen_hide"><br><br></span>
        <a href="//www.centurylink.com/aboutus/" clicktrack="ctl|corp|footer|link|about_us">About Us</a> |
        <a href="https://www.centurylink.com/aboutus/companyinformation/careers/" rel="nofollow" clicktrack="ctl|corp|footer|link|careers">Careers</a> |
        <a href="http://ir.centurylink.com" rel="nofollow" clicktrack="ctl|corp|footer|link|investor_relations">Investor Relations</a> |
        <!-- <a href="http://news.centurylink.com/" rel="nofollow" clicktrack="ctl|corp|footer|link|newsroom">Newsroom</a> | -->
        <a href="//www.centurylink.com/aboutus/legal.html" rel="nofollow" clicktrack="ctl|corp|footer|link|legal">Legal</a> |
        <a href="http://www.centurylink.com/Legal/" rel="nofollow" clicktrack="ctl|corp|footer|link|legal_notices">Legal Notices</a> |
        <a href="//www.centurylink.com/aboutus/legal/privacy-policy.html" rel="nofollow" clicktrack="ctl|corp|footer|link|privacy_policy">Privacy Policy</a> |
        <a href="//www.centurylink.com/sitemap.html" rel="nofollow" clicktrack="ctl|corp|footer|link|site_map">Site Map</a>
        <!-- <span class="tablet_hide"> |</span> -->
        <!-- <span class="mobile_hide fullscreen_hide"><br></span> -->
        <a href="//www.centurylink.com/aboutus/legal/tariff-library.html" rel="nofollow" clicktrack="ctl|corp|footer|link|tariffs">Tariffs</a> |
        <a href="//www.centurylink.com/home/help/contact.html" clicktrack="ctl|corp|footer|link|contact_us">Contact Us</a>
        <br>
        <a href="//www.centurylink.com/aboutus/community/community-development/programs-for-customers-with-disabilities.html" clicktrack="ctl|corp|footer|link|customer_disabilities">Customers with Disabilities</a> |
        <a href="http://storelocator.centurylinkapps.com/" rel="nofollow" clicktrack="ctl|corp|footer|link|store_locator">Store Locator</a> |
        <!-- <a href="/local/" clicktrack="ctl|rsd|footer|link|local">CenturyLink in Your Area</a> | -->
        <!-- <a href="#ZAM" rel="nofollow" class="modal-trigger" id="tpl_footer-yellow-pages" clicktrack="ctl|corp|footer|link|yellow_pages">White/Yellow Pages</a> -->
        <!-- <a href="http://www.dexpages.com/" rel="nofollow" id="footerWYPages" clicktrack="ctl|corp|footer|link|yellow_pages" style="display: none;">White/Yellow Pages</a> | -->
        <!-- <a href="#ZAM" class="modal-trigger" id="tpl_footer-referral-program" rel="nofollow" clicktrack="ctl|corp|footer|link|referral_program">Referral Program</a> | -->
        <a href="http://www.localinternetservice.com/" rel="nofollow" clicktrack="ctl|rsd|footer|link|centurylink_retailer">CenturyLink Retailer</a> |
        <a href="http://beyondthewires.centurylink.com" clicktrack="ctl|rsd|footer|link|guide_to_home_technology" class="removeLinkSplit">Guide to Home Technology</a> |
        <a href="//www.centurylink.com/business/federal-gov/" rel="nofollow" clicktrack="ctl|corp|footer|link|federal_government">Fed Govt</a> |
        <a href="//www.centurylink.com/business/state-and-local-gov/" rel="nofollow" clicktrack="ctl|corp|footer|link|statelocal_government">State &amp; Local Gov’t</a> |
        <a href="//www.centurylink.com/business/education/" rel="nofollow" clicktrack="ctl|corp|footer|link|education">Education</a> |
        <a href="//www.centurylink.com/business/partners/" rel="nofollow" clicktrack="ctl|corp|footer|link|partners">Partners</a>
        <br>
        <a href="//www.centurylink.com/home/" clicktrack="ctl|corp|footer|link|for_home">For Home</a> |
        <a href="//www.centurylink.com/small-business/" clicktrack="ctl|corp|footer|link|small_business">Small Business</a> |
        <a href="//www.centurylink.com/business/" clicktrack="ctl|corp|footer|link|medium_enterprise">Medium — Enterprise</a> |
        <a href="//www.centurylink.com/wholesale/" clicktrack="ctl|corp|footer|link|wholesale">Wholesale</a>
        <!-- <span class="mobile_hide fullscreen_hide"> |</span> -->
        <!-- <a class="mobile_hide fullscreen_hide user-locale" href="#" onclick="return chooser();
        function chooser(){
        var script=document.createElement('SCRIPT');
        script.src='https://centurylinkresidential.mpeasylink.com/mpel/mpel_chooser.js';
        document.body.appendChild(script);
        return false;
        }" title="Global Switch">Español</a> -->
        <br>
        <div id="copyright_text">
			&copy; <span id="copyright_year_wrapper">2018</span>, CenturyLink. All Rights Reserved.
		</div>
		
		<noscript></noscript>
		
        <!--US12484 - Added alt message to achieve ADA compliance-->
        <div v-show="!isDev">
        <a class="footerFeedback" href="#" id="ol_static_footer_feedback_link" onclick="return !OOo.oo_feedback.show(event);">Feedback&nbsp;&nbsp;<img src="//www.centurylink.com/common/3rdparty/opinionlab/5/oo_icon.gif" title="Feedback" alt="Feedback"></a>
        </div>
        <div v-show="isDev">
            <a  class="footerFeedback" href="http://aglopww411/dceras" target="_blank"> <label>Submit Ticket&nbsp;&nbsp;<img src="//www.centurylink.com/common/3rdparty/opinionlab/5/oo_icon.gif"/></label></a>
            </div>
    </div>
</div>

</template>
<script>
    export default {
		name: "NavBar",
		data() {
			return {
                isDev: process.env.NODE_ENV === 'development'
            }
        }
    };
</script>
<style scoped>

    .sml-logo{
        background: url("../../static/img/ctl_logo_smaller.png") no-repeat transparent;
        float: left;
        width: 108px;
        height: 22px;
        margin:15px;
    }
    @media (max-width: 991px){
        .container {
            display: none;
        }
    }
    @media (min-width: 1200px){
        .container {
            width: 990px;
        }
    }
    @media (min-width: 992px){
        .container {
            width: 970px;
        }
    }
    @media (min-width: 991px){
        div#responsive-footer .footerFeedback {
            margin-left: 440px;
            margin-top: 0px;
            position: relative;
            bottom: 19px;
        }
    }
    .footer-new, .footer-new a {
        color: #666;
        font-size: 12px;
        line-height: 1.6em;
    }
    .container{
        margin-right: auto;
        margin-left: auto;
        padding-left: 15px;
        padding-right: 15px;
    }
</style>






