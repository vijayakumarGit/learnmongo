<template>
<nav>
    <div class="-d--flex -align-content--center nav-bar">
        <div class="-flex--fill -d--flex -flex--row -justify-content--between -align-items--center -mx3">
			<div class="brand -mr2">
				<img src="../../static/img/ctl_logo_larger.png">
			</div>
            <div class="-d--flex -flex--row -justify-content--end -align-items--center nav-bar__space-between">
                <div id="chat-consumer-sorrypage">
                    <div id="chat-consumer-header"><div id="LPMcontainer-1545234776147-5" class="LPMcontainer LPMoverlay" role="button" tabindex="0" style="margin: 1px; padding: 0px; border-style: solid; border-width: 0px; font-style: normal; font-weight: normal; font-variant: normal; list-style: none outside none; letter-spacing: normal; line-height: normal; text-decoration: none; vertical-align: baseline; white-space: normal; word-spacing: normal; background-repeat: repeat-x; background-position: left bottom; cursor: auto; display: block; position: relative; top: 0px; left: 0px;"><a data-lp-event="click"><div class="chat-icon"></div></a></div></div>
                </div>
            </div>
        </div>  
    </div>
    <div class="nav-bar-address row">  
        <div class="pageTitle col-sm-7 col-xs-12" >
		<strong class="select_speed">CenturyLink High-Speed Internet</strong><br>
		</div>
        <div class="ctaWelcome col-sm-5 col-xs-12" >
            <span><strong>Welcome | {{addressPartOne}} <br> {{addressPartTwo}}</strong></span>
            <div class="changeInfo">
            <a>Change Info |</a>
            <a>Already a Customer?</a>
            </div>
        </div>
    </div>
</nav>
</template>
<script>
     import $ from 'jquery';
export default {
    
    name: "NavBar",
    data() {
        return{
            addressPartOne: "6446 N MOORE AVE,",
            addressPartTwo: "PORTLAND, OR, 97217"
        }
    },
    mounted: function(){
        
        let digitalData = {};
            digitalData.event = [];
            digitalData.page = {
                            pageInfo: {
                                            page: "sorry",
                                            pageName: "http://sorry.centurylink.com",
                                            systemGroup: "static_page",
                                            cartPageCategory: "landing_page",
                                            server: "centurylink.com"
                            }
            };
        
        // let satelliteScript = document.createElement('script');
        // satelliteScript.setAttribute('src', '//assets.adobedtm.com/e2f8cd116ff52c784c699a7031ef84a705ee0e03/satelliteLib-7fa3624bda56a3da69adbf41e51715cd547aa343-staging.js')
        // document.head.appendChild(satelliteScript);

         if (typeof _satellite !== "undefined") _satellite.pageBottom();
    },
    created: function(){
    }
    
    }
</script>
<style scoped>
.nav-bar {
		background-color: var(--white);
		min-height: 75px;
		box-shadow: 0 2px 0 0 rgba(0, 0, 0, 0.12), 0 1px 0 0 rgba(0, 0, 0, 0.04);
        max-width: 990px;
        margin: auto;
	}
.nav-bar-address{
        max-width: 990px;
        margin: auto;

    }
.nav-bar__space-between :not(:last-child) {
		margin-right: 1vw;
	}
.nav-bar .brand img {
		width: auto;
		height: 34px;
	}
.pageTitle{
        margin: 15px 0;
        font-size: 20px;
        color: #666666;
        padding-left: 0px;
    }
.ctaWelcome{
    Text-align: right;
    margin-top: 10px;
    font-size: 12px;
    color: #666666;
    line-height: 1rem;
    padding-right: 0px;
}
.changeInfo{
        color: #001E60;
        cursor: pointer;
}
</style>


