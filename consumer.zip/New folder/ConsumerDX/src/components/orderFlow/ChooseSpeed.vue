<template>
    <div class="a-grid__container">
        <div class="-pt6">
            <span class="availableText">Greats speeds are available in your area.</span>
        </div>
        <div class="title_bars">
            <span class="bar greenBar"></span>
            <span class="bar grayBar"></span>
            <span class="bar blueBar"></span>
        </div>
        <div class="-mt4 -mb1">
			<div class="-d--flex -flex--column">
                <Button size="large" width="30" @click="openSurvey">Help Me Find The Right Speed For My Home</Button>
			</div>
        </div>
        <div class="-d--flex -flex--row -justify-content--start">
            <div class="-mb4"
                v-if="haveAnOffer">
                <Offers @selectedSpeed="pickedSpeed"></Offers>
            </div>
            <div class="-my4 consumer-landing__loading"
                v-else>
                <p>Hold on, we're checking for great offers at this address!</p>
                <div class="wrapper icon-padding">
                    <img src="/static/img/wait30.gif" />
                </div>
                <div class="-textCenter -pb2">
                    <p>Looking for other products or to bundle your Internet service?  <a href="" target="blank">Home Phone</a> | <a href="" target="blank">TV</a></p>
                </div>
            </div>
        </div>
        <div class="-textCenter -pb2">
            <p>Looking for other products or to bundle your Internet service?  <a href="" target="blank">Home Phone</a> | <a href="" target="blank">TV</a></p>
        </div>
    </div>
</template>


<script>
import Offers from "@/components/shared/orderFlow/Offers"
import Button from '@/components/shared/components/Button';
export default {
    name: 'ChooseSpeed'
    ,props: [],
    components: {
        Offers
        , Button
    }
    , data(){
		return {
            isSelectedProduct: false
            ,isActive: false
            ,selectedName: ''
            ,objOrder: null
            ,isPlanSelected: false

		}
    }
    , created: function(){       
    }
    , mounted: function() {
    }
    , computed: {
		productOffers() {    
            let offersObj = this.$store.getters.getOffers;

            if (!!offersObj && offersObj.length > 0 && !!offersObj[0].offers) {
                return offersObj[0].offers;
            }

            return undefined;
        },
        haveAnOffer() {
            return !!this.productOffers;
        }
    }
    , methods: {
        pickedSpeed: function(speed){	
            this.$router.push("/serviceOptions");
        }
        , openSurvey: function(){
            this.$router.push("/Survey");
        }
    }
    
}
</script>

<style scoped>
    .availableText{
        font-size: 3rem;
    }
    .title_bars{
        width: 75%;
    }
    .wrapper{
        display: flex;
        justify-content: center;
    }
    .consumer-landing__loading {
        text-align: center;
        width: 30rem;
    }
@media screen and (max-width: 990px) {
    .availableText{
        font-size: 2rem;
    }
    .title_bars{
        width: 100%;
    }
    .bar.greenBar {
        width: 25%;
    }
    .bar.grayBar {
        width: 25%;
    }
    .bar.blueBar {
        width: 50%;
    }
}
</style>



