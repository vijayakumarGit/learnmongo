<template>
    <div ref="serviceOptions" id="serviceOptions" class="a-grid__container">
        <div class="-pt2 a-grid">
            <div class="col-xs-12 col-md-8">
                <div id="tracker" class="-my2">
                    <p>tracker component will come in here. </p>
                </div>
                <div id="pageTitle" >
                    <p class="-textBolder a-h3">Choose Your Service Options</p>
                </div>
                <div id="modemOptions">
                    <p>Modem Options component will be here</p>
                </div>
                <div id="installOptions">
                    <p>Installation Options component will be here</p>
                </div>
            </div>
            <div class="col-xs-12 col-md-4">
                <div class="-my2">
                    <OrderSummary></OrderSummary>
                </div>
            </div>
        </div>
    </div>    
</template>

<script>
import OrderSummary from '@/components/shared/orderFlow/OrderSummary';
export default {
    name: 'ServiceOptions'
    , components: {
        OrderSummary
    }
    , data(){
        return{

        }
    }
}
</script>

<style scoped>
</style>
