<template>
    <div class="survey -d--flex -flex--row -justify-content--center">

        <div v-if="openLayout === survey"
            class="survey__left-side -d--flex -flex--column -pb3">
            <span class="survey__back -p3" @click="close()">
                <i class="fas fa-home survey__home"></i>
                <span class="-pl1">Back to Main</span>
            </span>

            <div class="-py3">
                <Progress :steps="steps" :selected="currentStep" :pointerTo="majorStep"
                    @click="availableToGoto($event)" />
            </div>
        </div>

        <div v-if="openLayout === survey"
            class="survey__right-side -flex--fill -d--flex -flex--column -p3 -bl1">
            <div class="-d--flex -flex--row -justify-content--between">
                <div class="-flex-survery-xs--column">
                    <span class="back__home -py3 survey__home-xs-container" @click="close()">
                        <i class="fas fa-home home"></i>
                        <span class="-pl1">Back to Main</span>
                    </span>
                    <Button v-if="!!currentConfiguration.path.back"
                        size="medium" width="5" @click="gotoPath(currentConfiguration.path, 'back')">Back</Button>
                </div>

                <div class="-d--flex -flex--row -justify-content--end -flex-survery-xs--column">
                    <Button v-if="currentStep > 1 && isResetAvailable"
                        size="medium" width="6" @click="gotoSurvey('startOver')">Start Over</Button>
                    <Button
                        :disabled="!canSave"
                        size="medium" width="5" @click="saveState()">Save</Button>
                </div>
            </div>


            <div class="-flex--fill -d--flex -flex--column -justify-content--between">

                <h2 v-if="!!currentConfiguration.title" v-html="currentConfiguration.title"></h2>


                <div v-if="!!currentConfiguration.addressAutoComplete"
                    class="survey__input -my3 -d--flex -flex--column">

                    <span class="-ml2 -mb1" :class="getClasses(currentConfiguration.addressAutoComplete.labelSize)"
                        v-html="currentConfiguration.addressAutoComplete.label"></span>
                    <!-- <AddressAutoComplete
                        :preloadAddressValue="currentData[currentConfiguration.addressAutoComplete.saveOn]" :fromConsumer="true"
                        @pass-input="resetAddress(currentConfiguration.addressAutoComplete.saveOn)"
                        @pass-selected-address="saveAddress($event, currentConfiguration.addressAutoComplete.saveOn)"
                        @pass-showLoading="showLoading()"></AddressAutoComplete> -->
                </div>


                <ChooseCard v-if="!!currentConfiguration.chooseCard"
                    :label="currentConfiguration.chooseCard.label" :labelSize="currentConfiguration.chooseCard.labelSize"
                    :options="currentConfiguration.chooseCard.options" :optionsSize="currentConfiguration.chooseCard.optionsSize"
                    :type="currentConfiguration.chooseCard.type" :select="currentData[currentConfiguration.chooseCard.saveOn]"
                    v-on:selected="save($event, currentConfiguration.chooseCard.saveOn)">

                    <template slot-scope="{row}">
                        <div class="choose-card__content -flex--fill -d--flex -flex--column -justify-content--around -align-items--center" v-html="row"></div>
                    </template>
                </ChooseCard>


                <p v-if="!!currentConfiguration.p"
                    v-show="!!currentConfiguration.p.showIf ? getCondition(currentConfiguration.p.showIf) : true"
                    class="-my3" :class="getClasses(currentConfiguration.p.labelSize)"
                    v-html="currentConfiguration.p.label"></p>


                <div v-if="!!currentConfiguration.input"
                    class="survey__input -my3 -d--flex -flex--column">

                    <span class="-ml2 -mb1" :class="getClasses(currentConfiguration.input.labelSize)"
                        v-html="currentConfiguration.input.label"></span>
                    <input type="text" v-model="currentData[currentConfiguration.input.saveOn]" />
                </div>


                <CountCard v-if="!!currentConfiguration.countCard"
                    :label="currentConfiguration.countCard.label" :labelSize="currentConfiguration.countCard.labelSize"
                    :options="currentConfiguration.countCard.options" :optionsSize="currentConfiguration.countCard.optionsSize"
                    :values="currentData[currentConfiguration.countCard.saveOn]"
                    v-on:selected="save($event, currentConfiguration.countCard.saveOn)">

                    <template slot-scope="{row}">
                        <div class="count-card__content -d--flex -flex--column -justify-content--center -align-items--center" v-html="row"></div>
                    </template>
                </CountCard>


                <div v-if="!!currentConfiguration.path.next"
                    class="-my3 -d--flex -flex--row -align-items--center -flex-survery-xs--column -justify-content--center">
                    <Button
                        v-if="!currentConfiguration.mandatory"
                        size="large" @click="removeSaveStoreAndGotoPath(currentConfiguration.path)">Skip</Button>
                    <Button
                        :disabled="currentDataIsEmpty"
                        size="large" @click="saveStoreAndGotoPath(currentConfiguration.path)">Continue</Button>                   
                </div>

                <div v-else
                    class="-my3 -d--flex -flex--row -align-items--center -justify-content--center">
                    <Button
                        outline="false" size="large" width="15"
                        :disabled="currentDataIsEmpty"
                        @click="saveAndGotoResults()">See Your Results</Button>
                </div>

            </div>
        </div>

        <div v-if="openLayout === surveyResults"
            class="-flex--fill">

            <SurveyResults :isResetAvailable="isResetAvailable"
                @close="close()" @back="gotoSurvey($event)"></SurveyResults>
        </div>
    </div>

</template>

<script>
import Progress from '@/components/survey/Progress';
// import AddressAutoComplete from '@/components/shared/addresses/AddressAutoComplete';
import ChooseCard from '@/components/survey/ChooseCard';
import CountCard from '@/components/survey/CountCard';
import Button from '@/components/shared/components/Button';
import SurveyResults from '@/components/survey/SurveyResults';
import { SURVEY, SURVEY_RESULTS, SURVEY_SHARE } from '@/mixin';

export default {
    name: 'Survey'
    , props: []
    , components: {
        Progress
        // , AddressAutoComplete
        , ChooseCard
        , CountCard
        , Button
        , SurveyResults
    }
    , data() {
        return {
            survey : SURVEY
            , surveyResults: SURVEY_RESULTS
            , surveyShare: SURVEY_SHARE
            , openLayout: ''
            , stepsSaved: {}
            , isSaved: false
            , currentStep: 1
            , majorStep: 1
            , currentData: {}
            , isResetAvailable: true
        }
    }
    , computed: {
        getSurveyConfiguration() {
            return this.$store.getters.surveyConfiguration;
        }
        , steps() {
            let configurationSteps = [];
            let currentUserData = this.$store.getters.surveyData;

            this.getSurveyConfiguration.forEach(configurationStep => {
                let saved = false;

                if (!!currentUserData) {
                    for (let item in configurationStep.content) {
                        if (!!configurationStep.content[item].saveOn && !!currentUserData[configurationStep.content[item].saveOn]) {
                             saved = true;
                             break;
                        }
                    }
                }

                configurationSteps.push({ step: configurationStep.step, title: configurationStep.title, saved: saved });
            });

            for (let step in this.stepsSaved) {
                configurationSteps[step-1].saved = true;
            }

            return configurationSteps;
        }
        , currentConfiguration() {
            return !!this.getSurveyConfiguration[this.currentStep-1] ? this.getSurveyConfiguration[this.currentStep-1].content : {};
        }
        , isCurrentStepNotSaved() {
            return !this.stepsSaved[this.currentStep];
        }
        , areThereOffersAvailable() {
            return !!this.$store.getters.getOffers && this.$store.getters.getOffers.length > 0
                && !!this.$store.getters.getOffers[0].offers && this.$store.getters.getOffers[0].offers.length > 0;
        }
        , canSave: {
            get: function() {
                return (this.currentDataIsEmpty || this.isSaved) ? false : true;
            }
            , set: function(canSaveNow) {
                this.majorStep = this.currentStep;
                this.isSaved = !canSaveNow;
            }
            
        }
        , currentDataIsEmpty() {
            return Object.values(this.currentConfiguration).reduce((currentValue, element) => {
                if (!!element.saveOn && !this.currentData[element.saveOn]) {
                    return true;
                }

                return currentValue;
            }, false);
        }
    }
    , methods: {
        getClasses: function(classes) {
            return classes;
        }
        , getCondition: function(data) {
            let field;
            let myFunction = 'constructor';
            let genericFunction = 'return field ' + data.condition + ' value';

            if (data.isData) {
                field = Array.isArray(this.currentData[data.field]) ? this.currentData[data.field][0] : this.currentData[data.field];
            } else {
                field = Array.isArray(this[data.field]) ? this[data.field][0] : this[data.field];
            }

            return myFunction[myFunction][myFunction]('field', 'value', genericFunction)(field, data.value);
        }
        , close: function() {
            this.reset();
            this.$router.push('/ChooseSpeed');
        }
        , goto: function(step) {
            this.currentStep = step;

            if (step > this.majorStep) {
                this.majorStep = step;
            }
        }
        , gotoPath: function(path, direction) {
            let stepto = path[direction];

            if (!!path.rewrite && !!path.rewrite[direction] && this.getCondition(path.rewrite)) {
                stepto = path.rewrite[direction];
            }

            this.goto(stepto);
        }
        , gotoSurvey: function(step) {
            if (!!step && step === 'startOver') {
                this.reset();
            }

            this.openLayout = this.survey;
        }
        , availableToGoto: function(step) {
            if (step <= this.majorStep) {
                this.goto(step);
            }
        }
        , save: function(item, where) {
            if (item !== this.currentData[where]) {
                let data = {};

                delete this.currentData[where];
                data[where] = item;

                this.currentData = { ...this.currentData, ...data};

                this.majorStep = this.currentStep;
                this.canSave = true;
            }
        }
		, saveAddress: function(addressSelectedData, where) {
            if (addressSelectedData
                && JSON.stringify(addressSelectedData).indexOf('fullAddress') >= 0
                && addressSelectedData !== this.currentData[where])
            {
				var addLookup = JSON.stringify(addressSelectedData.fullAddress).replace(/['"]+/g, '');
				addressSelectedData.fullAddress = addLookup;
				sessionStorage.setItem('ChooseSpeedPageAddress',JSON.stringify(addressSelectedData));
				this.addressObj = [];
				this.addressObj.push(addressSelectedData);
				//then here we need to add it to the store to get offer data?
				// this.$store.dispatch('resetOffersData');
                this.$store.dispatch('setOffersStore', this.addressObj)
                    .then(() => this.save(addressSelectedData, where));
			}
        }
        , resetAddress: function(where) {
            sessionStorage.removeItem('ChooseSpeedPageAddress');
            this.$store.dispatch('resetOffersData');
            this.save('', where);
        }

        , saveStore: function() {
            let saveObject = {};
            saveObject = { ...saveObject, ...this.currentData };

            this.$store.commit('saveSurveyData', saveObject);
        }
        , reset: function() {
            this.$store.commit('resetSurveyId');
            this.$store.commit('resetSurveyData');
            sessionStorage.removeItem('ChooseSpeedPageAddress');
            sessionStorage.removeItem('selectedSpeed');

            this.stepsSaved = {};
            this.isSaved = false;
            this.currentStep = 1;
            this.majorStep = 1;
            this.currentData = { ...{}, ...this.$store.getters.surveyData };
        }
        , saveState: function() {
            this.stepsSaved[this.currentStep] = true;
            this.saveStore();

            if (!this.$store.getters.surveyUser) {
                let surveyGoto = JSON.stringify({ goto : this.survey, currentStep : this.currentStep });

                //TODO. REVIEW THIS CODE
                // sessionStorage.setItem('survey-goto', surveyGoto);
                // sessionStorage.setItem('signin-signup-sender','signup');
                // sessionStorage.setItem('signin-signup-goto','/Survey');
                // this.$router.push('/SignInSignUp');
            } else {
                this.$store.dispatch('saveSurveyData');
            }
            this.canSave = false;
        }
        , removeSaveStoreAndGotoPath: function(path) {
            for (let item in this.currentConfiguration) {
                if (!!this.currentConfiguration[item].saveOn) {
                    this.save('', this.currentConfiguration[item].saveOn);
                }
            }
            
            delete this.stepsSaved[this.currentStep];
            this.saveStore();
            this.gotoPath(path, 'next');
        }
        , saveStoreAndGotoPath: function(path) {
            this.stepsSaved[this.currentStep] = true;
            this.saveStore();
            this.gotoPath(path, 'next');
        }
        , saveAndGotoResults: function() {
            this.stepsSaved[this.currentStep] = true;
            this.saveStore();
            this.openLayout = this.surveyResults;
        }
		, showLoading: function(){
			this.addressEnteredSearching = true;
			this.simulateAndProceed = false;
			this.haveOfferAndAddress = true;
		}
		, weHaveAnOffer: function(){
			this.addressEnteredSearching = false;
        }
        , setOffersAndRedirect: function (surveyGoto, addressData) {
            this.$store.dispatch('setOffersStore', addressData)
                .then(() => {
                    if (surveyGoto.goto === this.survey) {
                        this.goto(surveyGoto.currentStep);
                        sessionStorage.removeItem('survey-goto');
                        this.openLayout = this.survey;

                    } else {
                        this.openLayout = this.surveyResults;
                    }
                });
        }
    }

    , created: function() {
        let surveyGoto = JSON.parse(sessionStorage.getItem('survey-goto'));

        this.$store.commit('resetCurrentSurvey');
        this.$store.commit('saveSurveyUser', sessionStorage.getItem('accountId') || '');

        if (!!surveyGoto) {

            if (!!surveyGoto.surveyId) {
                this.$store.commit('saveSurveyId', surveyGoto.surveyId);
                this.$store.dispatch('getSurveyDataById')
                    .then(() => {
                        this.isResetAvailable = false;
                        this.currentData = { ...{}, ...this.$store.getters.surveyData };
                        
                        //TODO. REVIEW THIS CODE
                        // this.setOffersAndRedirect(surveyGoto, [this.currentData['address']]);
                    });

            } else {
                this.$store.dispatch('saveSurveyData')
                    .then(() => {
                        this.currentData = { ...{}, ...this.$store.getters.surveyData };

                        //TODO. REVIEW THIS CODE
                        // this.setOffersAndRedirect(surveyGoto, [this.currentData['address']]);
                    });
            }

        } else {
            this.reset();
            this.openLayout = this.survey;
        }
    }
}
</script>
<style scoped>
.survey__right-side {
    max-width: 48rem;
}
.survey__back {
    color: var(--dk-gray);
    cursor: pointer;
    font-size: 1rem;
    font-weight: 600;
    letter-spacing: 0.028rem;
    line-height: 1.375rem;
}
.survey__home {
    color: var(--dk-gray);
    font-size: 1.25rem;
}

.survey__input span {
    color: var(--dk-gray);
    font-size: 0.9rem;
}
.survey__input input,
.survey__input >>> div .autocomplete input {
    border-radius: 1.5rem;
    border-style: unset;
    border-width: 1px;
    height: 2rem;
    padding-left: 1rem;
}
.survey__input >>> div {
    position: relative;
}
.survey__input >>> .autocomplete-results-consumer {
    left: 1rem;
    top: 2.1rem;
}
.chi h2 {
    line-height: 1.2;
}
.choose-card__content >>> p,
.count-card__content >>> p {
    text-align: center;
}
.choose-card__content >>> .type-service__title {
    color: var(--blue);
    font-weight: 600;
    font-size: 1rem;
}
.count-card__content >>> svg:not(:last-of-type) {
    margin-right: 0.5rem;
}

.small {
    font-size: 0.9rem;
}
.medium {
    font-size: 1.2rem;
}
.large {
    font-size: 2rem;
}

@media only screen and (min-width: 780px) {
    .survey__home-xs-container {
        display: none;
    }
    button:not(:last-child) {
        margin-right: 1rem;
    }
}
@media only screen and (max-width: 780px) {
    button:not(:first-child),button:not(:last-child) {
        margin-top: 0.25rem;
        margin-bottom: 0.25rem;
    }
    button:first-child {
        margin-top: 0rem;
    }
    button:last-child {
        margin-bottom: 0rem;
    }
    .-flex-survery-xs--column {
        flex-direction: column;
    }
    .survey__left-side {
        display: none;
    }
}
</style>
