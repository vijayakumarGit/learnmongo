<template>
    <div class="survey-share">

        <Layout :showBorderHeader="true" :showCloseButton="true" :showFooter="true" :showMenu="false">
            <template slot="title">Save and Share</template>

            <template slot="body">
                <div class="survey-share__content -pb6 -d--flex -flex--column -justify-content--around -align-items--center">
                    <p class="survey-share--message" :class="{ 'survey-share--error' : status !== 'SUCCESS' }"
                        v-if="!!message">{{ message }}</p>
                    
                    <div class="-d--flex -flex--column -align-items--center" :class="isEmailValid()">
                        <p class="survey-share__title">We've saved your results! your unique identifier is {{ getSurveyId }}</p>
                        <p>Who would you like to share this information with?</p>
                        <input type="text" class="a-input -large -mt2 survey-share__input" :class="{ '-danger' : hasError }"
                            placeholder="Email" v-model="email" 
                            @input="modified=true">
                    </div>

                    <Button
                        :disabled="!isShareable"
                        outline="false" size="large" width="15"
                        @click="share()">Share</Button>
                </div>
            </template>

        </Layout>
    </div>
</template>

<script>
import Layout from '@/components/shared/components/Layout';
import Button from '@/components/shared/components/Button';

export default {
    name: 'SurveyShare'
    , props: []
    , components: {
        Layout
        , Button
    }
    , data() {
        return {
            email: ''
            , hasError: false
            , reg: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,24}))$/
            , status: ''
            , message: ''
        }
    }
    , computed: {
        getSurveyId() {
            return this.$store.getters.surveyId;
        }
        , getSpeedDescription() {
            return this.$store.getters.getSpeedDescription;
        }
        , isShareable() {
            return !!this.email && !this.hasError;
        }
    }
    , methods: {
        isEmailValid: function() {
            let ccsClass = (this.email === '') ? '' : (this.reg.test(this.email)) ? 'has-success' : 'has-error';

            this.hasError = (ccsClass === 'has-error') ? true : false;

            return ccsClass;
        }
        , share: function() {
            let offersList = [];
            let selectedOffer = this.$store.getters.getSelectedOffer;

            if (this.$store.getters.getOffers[0]){

                this.$store.getters.getOffers[0].offers.forEach(offer => {
                    offersList.push({
                        'heading': offer.downloadDisplaySpeed
                        , 'description': this.getSpeedDescription[offer.tier]
                        , 'price': offer.price
                        , 'selected': !!selectedOffer && selectedOffer.skuName === offer.skuName
                    });
                });

            }

            this.$store.dispatch('shareSurvey', {
                    'baseURL': document.location.origin
                    , 'emailTo': this.email
                    , 'offersList' : offersList
                })
                .then((response) => {
                    this.status = response.data.status;
                    this.message = response.data.message;
                });
        }
    }
    , created: function() {}
}
</script>

<style scoped>
.survey-share >>> .sh-modal__backdrop {
    position: fixed;
    z-index: 1;
}
.survey-share__content {
    height: 33rem;
}
.survey-share__title {
    font-size: 1.5rem;
    font-weight: 300;
}
.survey-share .survey-share__content .survey-share__input {
    width: 27rem;
}
.survey-share--message {
    font-size: 1.2rem;
    font-weight: 300;
    margin-bottom: 0;
}
.survey-share--error {
    color: var(--red-600);
}
.has-error {
    border-color: var(--red-600);
}
</style>
