<template>
    <div>
        <SurveyShare v-if="openLayout === surveyShare" @close="openLayout = ''"></SurveyShare>

        <div v-else>
            <div class="-p3 -d--flex -justify-content--between survey-results__header">
                <span class="back__home -py3" @click="close()">
                    <i class="fas fa-home home"></i>
                    <span class="-pl1">Back to Main</span>
                </span>

                <div class="-d--flex -align-items--center -flex-survery-xs--column">
                    <Button size="medium" width="6" @click="back()">Back</Button>
                    <Button v-if="isResetAvailable" size="medium" width="7" @click="resetAndGotoInit()">Start Over</Button>
                    <Button size="medium" width="7" @click="saveOrShare()">Save/Share</Button>
                </div>
            </div>
            
            <div v-if="!isSimulateActive">
                <div class="-py3 -d--flex -flex--column -align-items--center" ref="resultsBlock">

                    <div class="-textCenter">
                        <p class="pageTitle">Your Quiz Results For:</p>
                        <span class="-textThin"> {{ displayAddress }} </span>
                    </div>

                    <div class="-d--flex -flex--row -flex-survery-xs--column survey-results__grid">
                        <div class="-flex-survey-xs--items -pr4">
                            <p class="text-black-50">Household Usage Profile</p>
                            <div class="-d--inline-flex -flex--row -align-items--center">
                                <p class="-mr4 usageTitleText">{{ usageTitleText }}</p>
                                <div class="-d--flex -flex--row arrow--color">
                                    <i class="fas fa-arrow-down fa-4x"></i>
                                    <i class="fas fa-arrow-up fa-4x"></i>
                                </div>
                            </div>
                            <p class="text-black-50">{{ usageText }}</p>
                        </div>

                        <div class="-flex-survey-xs--items profileCol--border">
                            <p class="text-black-50">Our Recommended Speed</p>
                            <div class="-d--inline-flex -flex--row -align-items--center">
                                <p class="-mr1 recommendTitleText">{{ recommendSpeed }}</p>
                                <div class="-d--flex -flex--row arrow--color">
                                    <i class="fas fa-plus fa-4x"></i>
                                    <span class="mbps--style -textBold">Mbps</span>
                                </div>
                            </div>
                            <p class="text-black-50">We recommend a minimum bandwidth of {{ recommendSpeed }} Mpbs to ensure that you can perform all of your desired activities at once without interruptions or slow downs in your service</p>
                        </div>

                    </div>


                    <h1 class="survey-results__offers-title--available -my4 -textBolder"
                        v-if="haveOffers">Great speeds are available in your area.</h1>

                    <Offers :speedFromSimulation="speedFromSimulation" @selectedSpeed="pickedSpeed" @passSpeedToBundle="passSpeedToBundle"></Offers>
                </div>

                <div v-if="simulateAndProceed" class="-d--flex -flex--column">
                    <div class="-mt3 -mb6 -d--flex -flex-survery-xs--column -justify-content--center -align-items--center">
                        <Button size="large" width="15" @click="simulateYourConnection">Simulate</Button>
                        <Button size="large" width="15" @click="proceedToCheckout">Proceed to Checkout</Button>
                        <!-- <Button size="large" @click="sendResultsEmail">Send Results Email</Button>                         -->
                    </div>

                    <div class="-mb3 survey-results__you-get--layout">
                        <div class="-textCenter -textBold availableText--size -mt3 -mb6">With CenturyLink You Get</div>
                        <div class="-d--flex -flex-survey-xs--column-reverse survey-results__ads-grid">

                            <div class="-d--flex -flex--column -flex-survey-xs--items survey-results__ads-grid__column-left">

                                <div class="-d--flex -align-items--end -pb5 -pl5">
                                    <div class="survey-resutls__column-33 -textRight survey-result--hidden">
                                        <img src="/static/img/survey/survey-results-modem.png/" class="survey-results__png">
                                    </div>

                                    <div class="survey-results__border survey-resutls__column-75 survey-results--fast-in">
                                        <svg height="18" width="18" class="survey-results__svg-left">
                                            <circle cx="9" cy="9" r="7" class="survey-results__circle" />
                                        </svg>
                                        <div class="-pr4 survey-results__ads-grid__column-left__padding-left">
                                            <p class="survey-results__bottom__title">Fast In-Home Wi-Fi</p>
                                            <p class="survey-results__bottom__text">Experience the ultimate WiFi connection to fast Internet connetion to fast Internet throughtout your entire home. CenturyLink In-home WiFi gives you a wireless Internet experience, allowing you to connect multiple devices to your home network. You'll have the speed and range to stream, game and upload with ease.</p>
                                            <a href="" class="">Learn More</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="-d--flex -pl5">
                                    <div class="survey-resutls__column-33"></div>
                                    <div class="survey-resutls__column-75 survey-results__border -my6">
                                        <div class="survey-results__ads-grid__column-left__padding-left survey-results__ads-grid__column-left__margin-right -d--flex -flex--column">
                                            <svg height="18" width="18" class="survey-results__svg-left">
                                                <circle cx="9" cy="9" r="7" class="survey-results__circle" />
                                            </svg>
                                            <div>
                                                <p class="survey-results__bottom__title">With all Internet orders, you can enjoy these benefits.</p>
                                                <a href="">Learn More</a>
                                            </div>
                                            <img src="/static/img/survey/survey-results-also-get.png/" class="survey-results__png survey-result--hidden">
                                        </div>
                                    </div>
                                </div>

                            </div>

                            <div class="-d--flex -flex--column -flex-survey-xs--items survey-resuts__ads-grid__column-right">
                                <div class="-d--flex -align-items--center">
                                    <div class="-mr4 survey-results__border survey-resutls__column survey-results__ads-grid__price">
                                        <svg height="18" width="18" class="survey-results__svg-right">
                                            <circle cx="9" cy="9" r="7" class="survey-results__circle" />
                                        </svg>
                                        <p class="survey-results__bottom__title">Price for Life</p>
                                        <p class="-mr4 survey-results__bottom__text">Your Internet rate won't change as long as you keep your CenturyLink Price For Life plan!<br>NO CONTRACT.<br>NO RATE HIKES.<br>NO BUNDLING NEEDED.</p>
                                    </div>
                                    <div class="-alignTop survey-resutls__column survey-result--hidden">
                                        <svg width="0" height="0">
                                        <defs>
                                            <clipPath id="clip-shape" clipPathUnits="objectBoundingBox">
                                            <polygon points="0 1, 0 0, 0.8 0, 0.8 1" />
                                            </clipPath>
                                        </defs>
                                        </svg>
                                        <img src="/static/img/survey/survey-results-laptop.png/" class="survey-results__png survey-results__laptop-svg">
                                    </div>
                                </div>

                                <div class="-d--flex survey-results__ads-grid__mobile survey-results__border -my6">
                                    <svg height="18" width="18" class="survey-results__svg-right">
                                        <circle cx="9" cy="9" r="7" class="survey-results__circle" />
                                    </svg>
                                    <div class=" survey-resutls__column suvey-result__ads-grid__mobile--text">
                                        <p class="survey-results__bottom__title">CenturyLink Mobile App</p>
                                        <p class="survey-results__bottom__text">Get your internet set up, manage your account and troubleshoot all in one place.</p>
                                        <a href="">Download Now</a>
                                    </div>
                                    <div class="survey-resutls__column -pt3 survey-result--hidden">
                                        <img src="/static/img/survey/survey-results-iphone.png/" class="survey-results__png">
                                    </div>
                                </div>

                            </div>

                        </div>

                    </div>
                </div>
            </div>

            <!-- <div v-if="isSimulateActive">
                <SimulateYourConnection :selectedSpeed="selectedSpeedValue" @passSpeedToBundle="passSpeedToResults"/>
                <div class="service-cta a-grid -mt6">
                    <Button size="large" @click="backToResults">Confirm Speed</Button>
                </div>
            </div> -->

        </div>
    </div>         
</template>

<script>
import Button from '@/components/shared/components/Button';
import Offers from "@/components/shared/orderFlow/Offers";
import SurveyShare from '@/components/survey/SurveyShare';
import { HSIAPI } from "@/http-common";
import { SURVEY_RESULTS, SURVEY_SHARE } from '@/mixin';

export default {
    name: 'SurveyResults'
    , props: ['isResetAvailable']
    , components: {
        Button
        , Offers
        , SurveyShare
    }
    , data() {
        return {
            speedFromSimulation: ""
            , simulateAndProceed: false
            , isSimulateActive: false
            , selectedSpeedValue: ''
            , openDialog: false
            , fromType:"consumer"
            , openLayout: ''
            , surveyResults: SURVEY_RESULTS
            , surveyShare: SURVEY_SHARE
        }
    }
    , computed: {
		surveyObj() {
            return this.$store.getters.surveyData;
        }
        , surveyResultsConf() {
            return this.$store.getters.surveyResultsConfiguration;
        }
        , usageTitleText() {
            return this.surveyObj.services[0];
        }
        , usageText() {
            let ut = this.surveyObj.services[0];
            let serviceType = this.surveyResultsConf.serviceType;

            return (!!serviceType && serviceType[ut]) || "not found";
        }
        , recommendSpeed() {
            let acts = this.surveyObj.activities[0];
            let userType = this.surveyObj.services[0];
            let recommendSpeed = this.surveyResultsConf.recommendSpeed;

            return (!!recommendSpeed && recommendSpeed[acts][userType]) || "not found";
        }
        , recommendText() {
            return  ;
        }
        , displayAddress() {
            return this.$store.getters.getAddress;
        }
        , haveOffers() {    
            var offersObj = this.$store.getters.getOffers;

            if (!!offersObj && offersObj.length > 0 && !!offersObj[0].offers && offersObj[0].offers.length > 0 && offersObj[0].offers[0].price > 0) {
                return true;
            }
            return false;
        }
    }
    , methods: {
        pickedSpeed: function(speed){
            this.simulateAndProceed = true;
            this.selectedSpeedValue = speed.downloadDisplaySpeed;
            this.$store.commit('saveOfferSelected', speed.downloadDisplaySpeed);
        }
		, simulateYourConnection: function(){
			this.isSimulateActive = false;
		}
		, proceedToCheckout: function(){
            //TODO. REVIEW THIS CODE
			var addr = [];
			addr = this.$store.getters.getAddressId; // 12-21-2018. now, we send the addressID
			addr[0].primary = true;
			this.$store.dispatch('setCustomerAddress', addr[0]);
			this.$store.dispatch('setCustomerAddresses', addr);
            
          	this.toggleSignUpModal();
			//adding a key to  session to let the orderDashboard know that we are 
			//coming from IDEO and need to start into the order flow
			sessionStorage.setItem("fromIdeo","yes");
		}
		, backToResults: function(){
			this.isSimulateActive = false;
		}
		, passSpeedToResults: function(newVal){
			this.speedFromSimulation = newVal;
		}
		, passSelectedSpeed: function(newVal){
			this.selectedSpeedValue = newVal;
		}
		, passSpeedToBundle: function(newVal){
			this.speedFromSimulation = newVal;
		}
		, toggleSignUpModal: function() {     
            sessionStorage.setItem("signin-signup-sender","signup");
       		sessionStorage.setItem("signin-signup-goto","/OrderDashboard");
      		this.$router.push("/SignInSignUp");
        }
        , close: function() {
            this.$emit('close');
        }
        , back: function() {
            this.$emit('back');
        }
        , saveOrShare: function() {
            if (!this.$store.getters.surveyUser) {
                let surveyGoto = JSON.stringify({ goto : this.surveyShare, currentStep : 0 });

                //TODO. REVIEW THIS CODE
                // sessionStorage.setItem('survey-goto', surveyGoto);
                // sessionStorage.setItem('signin-signup-sender','signup');
                // sessionStorage.setItem('signin-signup-goto','/Survey');
                // this.$router.push('/SignInSignUp');
            } else {
                this.$store.dispatch('saveSurveyData')
                    .then(() => { this.openLayout = this.surveyShare; });
            }
        }
        , resetAndGotoInit: function() {
            this.$emit('back', 'startOver');
        }
        , sendResultsEmail: function() {
            var whatever = this.$refs.resultsBlock;
            console.info("hsiapi_sendMail-block = "+ whatever );
            var postBody = {
                "content": JSON.stringify(whatever),
                "from": "mike.diehl@centurylink.com",
                "subject": "Test Email",
                "to": "mike.diehl@centurylink.com"
            };
            HSIAPI.post(
                "sendMail",
                postBody,
                { headers: {'Content-Type': 'application/json' }}
            ).then(response => {
                var rsp = response.data;
                console.info("hsiapi_sendMail-response = "+JSON.stringify(rsp));
            } );
        }
    }
    , created: function() {
        let surveyGoto = JSON.parse(sessionStorage.getItem('survey-goto'));

        if (!!this.$store.getters.offerSelected) {
            this.speedFromSimulation = this.$store.getters.offerSelected;
        }

        if (!!surveyGoto && surveyGoto.goto === this.surveyShare) {
            this.openLayout = this.surveyShare;
        }

        sessionStorage.removeItem('survey-goto');
    }
}
</script>
<style scoped>
.offers__line {
    max-width: 480px;
}
.offers__line--green {
    fill: var(--mint-green);
}
.offers__line--gray {
    fill: var(--md-gray);
}
.offers__line--blue {
    fill: var(--blue);
}


.survey-results__header {
    margin: auto;
    max-width: 61.5rem;
}
.back__home {
    color: var(--dk-gray);
    cursor: pointer;
    font-size: 1rem;
    font-weight: 600;
    letter-spacing: 0.028rem;
    line-height: 1.375rem;
    max-width: 65rem;
}
@media only screen and (min-width: 780px) {
    button:not(:last-child) {
        margin-right: 1rem;
    }
    .profileCol--border {
        border-left: 2px solid var(--mint-green);
        padding-left: 2rem;
    }
    .-flex-survey-xs--items {
        flex-basis: 50%;
    }
    .survey-results__ads-grid {
        margin-top: -5rem;
    }
    .survey-results__ads-grid__column-left {
        padding-top: 13rem;
        padding-right: 2rem;
    }
    .survey-resuts__ads-grid__column-right {
        padding-left: 2rem;
    }

    .survey-results__ads-grid__column-left__padding-left {
        padding-left: 4rem;
    }
    .survey-results__ads-grid__column-left__margin-right {
        margin-right: -3rem;
    }
    .survey-results__ads-grid__price {
        margin-top: 6rem;
    }
    .survey-results__ads-grid__mobile {
        margin-left: 4rem;
        margin-right: 8rem;
    }
    .survey-results--fast-in {
        margin-left: -8%;
    }
    .survey-resutls__column {
        flex-basis: 50%;
    }
    .survey-resutls__column-33 {
        flex-basis: 33%;
    }
    .survey-resutls__column-75 {
        flex-basis: 75%;
    }
}
@media only screen and (max-width: 780px) {
    button:not(:first-child),button:not(:last-child) {
        margin-top: 0.25rem;
        margin-bottom: 0.25rem;
    }
    button:first-child {
        margin-top: 0rem;
    }
    button:last-child {
        margin-bottom: 0rem;
    }
    .profileCol--border {
        border-top: 2px solid var(--mint-green);
    }
    .survey-results__ads-grid__mobile {
        margin-right: 2rem;
    }
    .survey-results__ads-grid__price > *:not(svg) {
        margin-left: 1rem;
    }
    .suvey-result__ads-grid__mobile--text {
        margin-left: 1rem;
    }
    .-flex-survery-xs--column {
        flex-direction: column;
    }
    .-flex-survey-xs--column-reverse {
        flex-direction: column-reverse;
    }
    .survey-results__ads-grid {
        margin-top: 0rem;
    }
    .survey-result--hidden {
        display: none;
    }
}

.survey-results__you-get--layout {
    background-color: var(--white);
}
.survey-results__grid {
    max-width: 50rem;
    margin: 2.5rem auto;
}

.home {
    color: var(--dk-gray);
    font-size: 1.25rem;
}

.pageTitle{
    font-size: 1.25rem;
    font-weight: 600;
}
.usageTitleText{
    font-size: 5vw;
    font-weight: 600;
    line-height: 5vw;
}
.recommendTitleText{
    font-size: 9vw;
    font-weight: 600;
    line-height: 10vw;
}
.arrow--color{
    color: var(--mint-green);
    min-width: 8rem;
}
.mbps--style{
    color: black; 
}

.survey-results__offers-title--available {
    font-size: 48px;
    font-weight: 300;
    line-height: 50px;
}

.availableText--size {
    font-size: 3rem;
    line-height: 3rem;
}
.survey-results__circle {
    fill: var(--white);
    stroke: var(--mint-green);
    stroke-width: 2;
}
.survey-results__border {
    border-top: 2px solid var(--mint-green);
    position: relative;
}
.survey-results__svg-left {
    left: -10px;
    position: absolute;
    top: -10px;
}
.survey-results__svg-right {
    left: 99%;
    position: absolute;
    top: -10px;
}

.survey-results__png {
    height: auto;
    max-width: 100%;
}
.survey-results__laptop-svg {
    clip-path: url("#clip-shape");
}

.survey-results__bottom__title {
    font-size: 1.8rem;
    font-weight: 600;
    line-height: 2rem;
    margin-top: 1rem;
}
.survey-results__bottom__text {
    color: var(--dk-gray);
    font-size: 1rem;
    font-weight: 600;
    line-height: 1.5rem;
}
a {
    color: var(--mint-green);
    cursor: pointer;
    font-size: 1rem;
    font-weight: 400;
    line-height: 1.5rem;
    text-decoration: underline;
}

</style>
