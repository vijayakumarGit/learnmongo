<template>
    <div class="survey-progress">
        <List :list="minimalSteps">

            <template slot-scope="{row}">
                <li :class="{ '-active' : isSelected(row.step) }">
                <a @click="emitEvent(row.step)" :class="{ 'disabled' : row.step > pointerTo }">
                    <div class="-d--flex -flex--row -align-items--center -pr3">
                        <CheckIcon :selected="row.saved" :size="'m'" />
                        <span class="survey-progress__title -pl2">{{ row.title }}</span>
                    </div>
                </a>
                </li>
            </template>

        </List>
    </div>
</template>

<script>
import List from '@/components/shared/components/List';
import CheckIcon from '@/components/shared/components/CheckIcon';

export default {
    name: 'Progress'
    , props: ['steps', 'selected', 'pointerTo']
    , components: {
        List
        , CheckIcon
    }
    , data() {
        return {
        }
    }
    , computed: {
        minimalSteps() {
            let stepsWithoutRepetition = [];
            let lastTitle = '';

            this.steps.forEach(step => {
                let relatedTo = [];

                if (step.title === lastTitle) {
                    stepsWithoutRepetition[stepsWithoutRepetition.length-1].relatedTo.push(step.step);

                } else {
                    stepsWithoutRepetition.push({step: step.step, title: step.title, saved: step.saved, relatedTo: relatedTo});
                    lastTitle = step.title;
                }
            });

            return stepsWithoutRepetition;
        }
    }
    , methods: {
        isSelected: function(step) {
            if (!this.selected) {
                return false;
            }

            let stepShown = this.minimalSteps.find(minimalStep => {
                return minimalStep.step === this.selected ||
                    !!(minimalStep.relatedTo.find(relatedTo => relatedTo === this.selected));
            })

            return stepShown.step === step;
        }
        , emitEvent: function(step) {
            this.$emit('click', step);
        }
    }
}
</script>

<style scoped>
.survey-progress__title {
    color: var(--md-gray);
    font-size: 1.125rem;
    font-weight: 600;
}
.survey-progress li.-active {
    background-color: var(--white);
}
.chi .a-tabs.-vertical:not(.a-tabs--js)>li.-active>a:before {
    background-color: var(--white);
}
.survey-progress .list .a-tabs>li>a.disabled {
    cursor: unset;
}
</style>

