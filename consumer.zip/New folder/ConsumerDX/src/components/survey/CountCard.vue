<template>
    <div class="count-card -d--flex -flex--column -my3">
        <span class="-ml2" :class="getClasses(labelSize)" v-html="label"></span>

        <div class="count-card__container -d--flex -flex--row -flex--wrap">
            <div class="count-card__element -d--flex -flex--column -justify-content--center -align-items--center"
                :style="{ 'width': getWidth(), 'height': getHeight(), 'border-radius': borderRadius }"
                ref="option"
                v-for="element in options" :key="element.value">
                <slot :row="element.label"></slot>
                <div>
                    <span @click="minusAndEmitEvent(element.value)"><i class="fal fa-minus colorGreen"></i></span>
                    <span>{{ getValue(element.value) }}</span>
                    <span @click="addAndEmitEvent(element.value)"><i class="fal fa-plus colorGreen"></i></span>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'CountCard'
    , props: ['label', 'labelSize', 'options', 'optionsSize', 'values']
    , components: {
    }
    , data() {
        return {
            borderRadius: 0
        }
    }
    , methods: {
        getClasses: function(classes) {
            return classes;
        }
        , getWidth: function() {
            return (!!this.optionsSize && this.optionsSize.length >= 1) ? this.optionsSize[0] : 'auto';
        }
        , getHeight: function() {
            return (!!this.optionsSize && this.optionsSize.length >= 2) ? this.optionsSize[1] : 'auto';
        }
        , setBorderRadius: function() {
            if (!!this.$refs.option) {
                if (!!this.optionsSize && this.optionsSize.length === 3 && this.optionsSize[2] !== 'auto') {
                    this.borderRadius = this.optionsSize[2];
                } else {
                    this.borderRadius = (!!this.$refs.option ? this.$refs.option[0].clientHeight / 32 : 0) + 'rem';
                }
            }
        }
        , getValue: function(item) {
            let element = Array.isArray(this.values) ? this.values.find(value => value.label === item) : undefined;
            return !!element ? element.value : 0;
        }
        , minusAndEmitEvent: function(item) {
            let valuesOutput = [ ...[], ...this.values ];
            let index = valuesOutput.findIndex(value => value.label === item);

            if (index > -1 && valuesOutput[index].value > 0) {
                valuesOutput[index].value = valuesOutput[index].value - 1;
            }

            this.emitEvent(valuesOutput);
        }
        , addAndEmitEvent: function(item) {
            let valuesOutput = [ ...[], ...this.values ];
            let index = valuesOutput.findIndex(value => value.label === item);

            if (index === -1) {
                valuesOutput.push({ label: item, value: 0 });
                index = valuesOutput.length - 1;
            }

            valuesOutput[index].value = valuesOutput[index].value + 1;

            this.emitEvent(valuesOutput);
        }
        , emitEvent: function(item) {
            this.$emit('selected', item);
        }
    }
    , mounted: function() {
        this.setBorderRadius();
    }  
    , updated: function() {
        this.setBorderRadius();
    }
}
</script>

<style scoped>
.count-card__container {
    margin-left: -0.5rem;
    margin-right: -0.5rem;
}
.count-card__element {
    background-color: var(--white);
    cursor: pointer;
    min-height: 2rem;
    margin: 0.5rem;
}
.-active {
    border: .0625rem solid var(--mint-green);
}
.small {
    color: var(--carbon-100);
    font-size: 0.9rem;
    margin-bottom: 0.5rem;
    line-height: 1rem;
}
.large {
    font-size: 2rem;
    font-weight: 700;
    margin-bottom: 1.5rem;
    line-height: 1.2;
}
.colorGreen {
    color: var(--mint-green);
}
</style>
