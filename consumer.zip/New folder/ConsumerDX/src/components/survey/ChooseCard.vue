<template>
    <div class="choose-card -d--flex -flex--column -my3">
        <span class="-ml2" :class="getClasses(labelSize)" v-html="label"></span>

        <div class="choose-card__container -d--flex -flex--row -flex--wrap">
            <div class="choose-card__element -d--flex -flex--row -justify-content--center -align-items--center"
                :class="{ '-active' : isSelected(element.value), '-flex--fill' : getWidth() === 'auto' }"
                :style="{ 'width': getWidth(), 'height': getHeight(), 'border-radius': borderRadius }"
                ref="option"
                @click="emitEvent(element.value)"
                v-for="element in options" :key="element.value">
                <slot :row="element.label"></slot>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'ChooseCard'
    , props: ['label', 'labelSize', 'options', 'optionsSize', 'type', 'select']
    , components: {
    }
    , data() {
        return {
            borderRadius: 0
        }
    }
    , methods: {
        getClasses: function(classes) {
            return classes;
        }
        , getWidth: function() {
            return (!!this.optionsSize && this.optionsSize.length >= 1) ? this.optionsSize[0] : 'auto';
        }
        , getHeight: function() {
            return (!!this.optionsSize && this.optionsSize.length >= 2) ? this.optionsSize[1] : 'auto';
        }
        , isSelected: function(item) {
            return !!this.select && this.select.length > 0 ? !!this.select.find(element => element === item) : false;
        }
        , setBorderRadius: function() {
            if (!!this.$refs.option) {
                if (!!this.optionsSize && this.optionsSize.length === 3 && this.optionsSize[2] !== 'auto') {
                    this.borderRadius = this.optionsSize[2];
                } else {
                    this.borderRadius = (!!this.$refs.option ? this.$refs.option[0].clientHeight / 32 : 0) + 'rem';
                }
            }
        }
        , emitEvent: function(item) {
            let selected = [item];

            if (!!this.type && this.type === 'multiple' && !!this.select && this.select.length > 0) {
                selected = selected.concat(this.select);
            }

            this.$emit('selected', selected);
        }
    }
    , mounted: function() {
        this.setBorderRadius();
    }  
    , updated: function() {
        this.setBorderRadius();
    }
}
</script>

<style scoped>
.choose-card__container {
    margin-left: -0.5rem;
    margin-right: -0.5rem;
    justify-content: center;
}
.choose-card__element {
    background-color: var(--white);
    cursor: pointer;
    min-height: 2rem;
    margin: 0.5rem;
}
.-active {
    border: .0625rem solid var(--mint-green)
}
.small {
    color: var(--carbon-100);
    font-size: 0.9rem;
    margin-bottom: 0.5rem;
    line-height: 1rem;
}
.large {
    font-size: 2rem;
    font-weight: 700;
    margin-bottom: 1.5rem;
    line-height: 1.2;
}
</style>
