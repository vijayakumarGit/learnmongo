<template>
	<div >
		<div class="layout a-grid__container"> 
			<div class="a-grid">
				<div class="-textBolder -textLeft -textLarger -mt6 a-col -w12">
					This page is to be used for testing the passing of an address to the CL Page.
				</div>
				<div class="title_bars col-md-12 ">
					<span class="bar greenBar"></span>
					<span class="bar grayBar"></span>
					<span class="bar blueBar"></span>
				</div>
				<div class="-textBold -textCenter -mt6 a-grid no-gutters">
					<div class="a-col -w4 -o1 text-right -align-self--center">Enter the address here:</div>
					<div class="a-col -w7 -textCenter">
						<input  type="text" class="a-input -large -success" placeholder=" just the geoAddressId - 205881146" style="width: 100%" v-model="addressInput"/>
					</div>
					<div class="-w3">
					</div>
				</div>
				<!-- <div class="a-grid__container"> -->
				<div class="-textCenter -mt6 a-grid" >
					<div class="a-col offset-3 -w7">
						<!-- <p>Will be sent to us something like: https://dce-consumer-mvp-master.kubeodc.corp.intranet/ChooseSpeed?sla=16306+HASCALL+ST+OMAHA+NE+68130&aid=205881146</p> -->
						</div>
				</div>
				<!-- </div> -->
			</div>
			<div class="-d--flex -flex--column">
				<div class="-mt6 -d--flex -justify-content--center -align-items--center">
					<Button size="large" width="15" @click="next">Next</Button>
				</div>
			</div>
		</div>
			
				
	</div>
</template>

<script>
import Button from '@/components/shared/components/Button';
export default {
	name: "Home",
	components: {
		Button
	},
	data() {
		return {
			addressInput: ''

		};
	},
	created() { 
	},
	methods: {
		next: function(){
			this.$store.dispatch("setAddressId", this.addressInput);
			this.$router.push("/ChooseSpeed");
		}
	}
};
</script>

<style scoped>


</style>

