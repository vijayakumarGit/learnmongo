// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import BootstrapVue from 'bootstrap-vue'
import App from './App'
import router from './router'

import "bootstrap/dist/css/bootstrap.min.css"
import "bootstrap-vue/dist/bootstrap-vue.css"

// Import Vue and vue2-collapse
import VueCollapse from 'vue2-collapse'
// Loading the plugin into the Vue.
Vue.use(VueCollapse)

import ToggleButton from 'vue-js-toggle-button'
Vue.use(ToggleButton)

require('jquery/dist/jquery');
require('bootstrap/dist/js/bootstrap');

import VueSVGIcon from 'vue-svgicon'
Vue.use(BootstrapVue);
Vue.use(VueSVGIcon);

import store from './store/index'

// import "./styles/chi.css";
import "./styles/main.css";
import "./styles/hcdeToken.css";


// import Vue-FontAwesome
import { FontAwesomeIcon, FontAwesomeLayers, FontAwesomeLayersText } from '@fortawesome/vue-fontawesome';
Vue.component('fa-icon', FontAwesomeIcon);
Vue.component('fa-layers', FontAwesomeLayers);
Vue.component('fa-layers-text', FontAwesomeLayersText);

Vue.config.productionTip = false



/* eslint-disable no-new */
new Vue({
  el: '#app',
   router,
   store,
   data: {
    
    retval: {}	
  },
  components: { App },
  template: '<App/>'  
})





  